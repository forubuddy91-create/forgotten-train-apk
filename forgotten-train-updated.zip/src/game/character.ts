// @ts-nocheck
import * as THREE from "three";

const CHAR_H = 1.68; // metres; the GLB is normalised to 1 unit tall

const FN = /* glsl */ `
uniform float uHipR, uHipL, uKneeR, uKneeL, uArmR, uArmL;
vec3 rotXp(vec3 p, float cy, float a, float isPos){
  vec3 q = p; q.y -= cy * isPos;
  float s = sin(a), c = cos(a);
  vec3 r = vec3(q.x, q.y*c - q.z*s, q.y*s + q.z*c);
  r.y += cy * isPos; return r;
}
// Procedural rigid-limb pose applied to the ORIGINAL, unmodified mesh.
vec3 skinAnim(vec3 pos, vec3 v, float isPos){
  float sideR = smoothstep(-0.02, 0.02, pos.x);
  float legW  = smoothstep(0.012, -0.03, pos.y);
  float kneeW = smoothstep(-0.17, -0.23, pos.y);
  float hip  = mix(uHipL, uHipR, sideR);
  float knee = mix(uKneeL, uKneeR, sideR);
  vec3 q = v;
  vec3 k = rotXp(q, -0.2, knee, isPos);
  q = mix(q, k, kneeW * legW);
  vec3 h = rotXp(q, 0.0, hip, isPos);
  q = mix(q, h, legW);
  float t = mix(0.14, 0.085, smoothstep(0.08, 0.16, pos.y));
  float armW = smoothstep(t, t + 0.03, abs(pos.x)) * smoothstep(0.35, 0.28, pos.y);
  float arm = pos.x > 0.0 ? uArmR : uArmL;
  vec3 a = rotXp(q, 0.3, arm, isPos);
  q = mix(q, a, armW);
  return q;
}
`;

export class PlayerModel {
  root = new THREE.Group();
  inner = new THREE.Group();
  mesh: THREE.Mesh;
  height = CHAR_H;
  u = {
    uHipR: { value: 0 },
    uHipL: { value: 0 },
    uKneeR: { value: 0 },
    uKneeL: { value: 0 },
    uArmR: { value: 0 },
    uArmL: { value: 0 },
  };
  phase = 0;
  amp = 0;
  runT = 0;
  action: { kind: string; t: number; dur: number; hold: boolean } | null = null;
  idleT = 0;
  lastStepIdx = 0;

  constructor(gltf: any) {
    let src: THREE.Mesh | null = null;
    gltf.scene.traverse((o: any) => {
      if (o.isMesh && !src) src = o;
    });
    const geo = src!.geometry;
    geo.computeBoundingBox();
    const bb = geo.boundingBox!;
    const mat = (src!.material as THREE.MeshStandardMaterial).clone();
    mat.envMapIntensity = 1.2;
    mat.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, this.u);
      sh.vertexShader = sh.vertexShader
        .replace("#include <common>", "#include <common>\n" + FN)
        .replace(
          "#include <beginnormal_vertex>",
          "vec3 objectNormal = skinAnim(position, normal, 0.0);\n#ifdef USE_TANGENT\nvec3 objectTangent = vec3(tangent.xyz);\n#endif"
        )
        .replace("#include <begin_vertex>", "vec3 transformed = skinAnim(position, position, 1.0);");
    };
    mat.customProgramCacheKey = () => "playerSkin";
    const mesh = new THREE.Mesh(geo, mat);
    mesh.frustumCulled = false;
    mesh.scale.setScalar(CHAR_H);
    mesh.position.y = -bb.min.y * CHAR_H; // feet on floor
    this.mesh = mesh;
    this.inner.add(mesh);
    this.root.add(this.inner);
    // soft contact shadow
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const g = c.getContext("2d")!;
    const gr = g.createRadialGradient(32, 32, 2, 32, 32, 30);
    gr.addColorStop(0, "rgba(0,0,0,0.75)");
    gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    const sh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.9, 0.9),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, fog: false })
    );
    sh.rotation.x = -Math.PI / 2;
    sh.position.y = 0.012;
    this.root.add(sh);
  }

  play(kind: string, dur: number, hold = false) {
    this.action = { kind, t: 0, dur, hold };
  }
  stop() {
    if (this.action) this.action.hold = false;
  }
  get busy() {
    return !!this.action && (this.action.hold || this.action.t < this.action.dur);
  }

  /** returns true when a foot plants */
  animate(dt: number, speed: number, walkSpeed: number, runSpeed: number): boolean {
    const sN = Math.min(speed / walkSpeed, 1);
    const rT = THREE.MathUtils.clamp((speed - walkSpeed) / (runSpeed - walkSpeed), 0, 1);
    this.runT += (rT - this.runT) * (1 - Math.exp(-dt * 8));
    this.amp += (sN - this.amp) * (1 - Math.exp(-dt * 10));
    const stride = THREE.MathUtils.lerp(1.5, 2.5, this.runT);
    this.phase += (dt * speed * Math.PI * 2) / stride;
    this.idleT += dt;
    let stepped = false;
    const idx = Math.floor(this.phase / Math.PI);
    if (idx !== this.lastStepIdx) {
      if (speed > 0.4 && this.amp > 0.35) stepped = true;
      this.lastStepIdx = idx;
    }
    const legAmp = this.amp * (0.42 + 0.34 * this.runT);
    const s = Math.sin(this.phase),
      c = Math.cos(this.phase);
    let hipR = s * legAmp,
      hipL = -s * legAmp;
    let kneeAmp = this.amp * (0.5 + 0.7 * this.runT);
    let kneeR = Math.max(0, c) * kneeAmp * (s > -0.2 ? 1 : 0.5);
    let kneeL = Math.max(0, -c) * kneeAmp * (s < 0.2 ? 1 : 0.5);
    const armAmp = legAmp * (0.75 + 0.5 * this.runT);
    let armR = -s * armAmp,
      armL = s * armAmp;
    let lean = this.amp * (0.04 + 0.12 * this.runT) + Math.sin(this.idleT * 1.3) * 0.006;
    let y = Math.abs(c) * 0.025 * this.amp * (1 + this.runT);
    // action overlay
    if (this.action) {
      const a = this.action;
      a.t += dt;
      let p = 0;
      if (a.kind === "pickup" || a.kind === "drop") p = Math.sin(Math.PI * Math.min(a.t / a.dur, 1));
      else {
        const rise = Math.min(1, a.t / 0.28);
        const fall = a.hold ? 1 : Math.min(1, Math.max(0, (a.dur - a.t) / 0.28));
        p = Math.min(rise, fall);
      }
      if (!a.hold && a.t >= a.dur) this.action = null;
      const w = 1 - p;
      if (a.kind === "pickup" || a.kind === "drop") {
        hipR = hipR * w - 0.7 * p;
        hipL = hipL * w - 0.7 * p;
        kneeR = kneeR * w + 1.3 * p;
        kneeL = kneeL * w + 1.3 * p;
        armR = armR * w - 0.7 * p;
        armL = armL * w - 0.7 * p;
        lean += 0.42 * p;
        y -= 0.2 * p;
      } else {
        const sw = a.kind === "operate" ? Math.sin(this.idleT * 4) * 0.12 : 0;
        armR = armR * w - (1.25 + sw) * p;
        armL = armL * w - 0.35 * p;
        lean += 0.08 * p;
      }
    }
    this.u.uHipR.value = hipR;
    this.u.uHipL.value = hipL;
    this.u.uKneeR.value = kneeR;
    this.u.uKneeL.value = kneeL;
    this.u.uArmR.value = armR;
    this.u.uArmL.value = armL;
    this.inner.rotation.x = lean;
    this.inner.position.y = y;
    return stepped;
  }
}
