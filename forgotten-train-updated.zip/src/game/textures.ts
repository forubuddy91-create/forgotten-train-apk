// @ts-nocheck
import * as THREE from "three";

export const SYMS = ["moon", "triangle", "star", "diamond", "circle", "square"];
export const SYM_NAMES = ["Moon", "Triangle", "Star", "Diamond", "Circle", "Square"];

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function mk(w: number, h: number, draw: (g: CanvasRenderingContext2D, w: number, h: number) => void) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  draw(c.getContext("2d")!, w, h);
  return c;
}
export function ct(c: HTMLCanvasElement, rx = 1, ry = 1, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.anisotropy = 4;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function speckle(g: CanvasRenderingContext2D, w: number, h: number, amt: number, seed: number) {
  const r = rng(seed);
  const id = g.getImageData(0, 0, w, h);
  const d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (r() - 0.5) * amt;
    d[i] += n;
    d[i + 1] += n;
    d[i + 2] += n;
  }
  g.putImageData(id, 0, 0);
}
function blotches(g, w, h, n, seed, col, amax, rmin, rmax) {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    const x = r() * w,
      y = r() * h,
      rad = rmin + r() * (rmax - rmin);
    const gr = g.createRadialGradient(x, y, 0, x, y, rad);
    gr.addColorStop(0, `rgba(${col},${(r() * amax).toFixed(3)})`);
    gr.addColorStop(1, `rgba(${col},0)`);
    g.fillStyle = gr;
    g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
}

export function wallCanvas() {
  return mk(512, 512, (g, w, h) => {
    g.fillStyle = "#3a464f";
    g.fillRect(0, 0, w, h);
    const r = rng(11);
    for (let i = 0; i < 2; i++)
      for (let j = 0; j < 2; j++) {
        g.fillStyle = `rgb(${52 + r() * 10},${66 + r() * 10},${76 + r() * 10})`;
        g.fillRect(i * 256 + 3, j * 256 + 3, 250, 250);
      }
    blotches(g, w, h, 40, 5, "20,24,26", 0.35, 30, 90);
    blotches(g, w, h, 34, 9, "120,62,28", 0.3, 15, 60);
    g.strokeStyle = "rgba(10,12,14,0.8)";
    g.lineWidth = 3;
    g.strokeRect(1, 1, 255, 255);
    g.strokeRect(257, 1, 254, 255);
    g.strokeRect(1, 257, 255, 254);
    g.strokeRect(257, 257, 254, 254);
    g.fillStyle = "rgba(140,150,150,0.5)";
    for (let k = 0; k < 16; k++) for (const [ox, oy] of [[0, 0], [256, 0], [0, 256], [256, 256]]) {
      g.beginPath();
      g.arc(ox + 10 + k * 15.5, oy + 10, 2, 0, 7);
      g.arc(ox + 10 + k * 15.5, oy + 246, 2, 0, 7);
      g.fill();
    }
    for (let i = 0; i < 26; i++) {
      const x = r() * w;
      const gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, "rgba(110,55,25,0)");
      gr.addColorStop(0.5, `rgba(110,55,25,${0.1 + r() * 0.25})`);
      gr.addColorStop(1, "rgba(60,30,15,0)");
      g.fillStyle = gr;
      g.fillRect(x, 0, 1 + r() * 3, h);
    }
    speckle(g, w, h, 22, 3);
  });
}
export function floorCanvas() {
  return mk(512, 512, (g, w, h) => {
    g.fillStyle = "#2b2a28";
    g.fillRect(0, 0, w, h);
    const r = rng(21);
    g.strokeStyle = "rgba(0,0,0,0.5)";
    g.lineWidth = 2;
    for (let i = 0; i <= 8; i++) {
      g.beginPath();
      g.moveTo(i * 64, 0);
      g.lineTo(i * 64, h);
      g.moveTo(0, i * 64);
      g.lineTo(w, i * 64);
      g.stroke();
    }
    g.strokeStyle = "rgba(90,86,80,0.35)";
    g.lineWidth = 1;
    for (let i = 0; i < 160; i++) {
      const x = r() * w,
        y = r() * h;
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(x + (r() - 0.5) * 30, y + (r() - 0.5) * 30);
      g.stroke();
    }
    blotches(g, w, h, 50, 4, "10,10,10", 0.5, 20, 80);
    blotches(g, w, h, 28, 8, "110,60,30", 0.25, 15, 55);
    blotches(g, w, h, 16, 12, "70,80,70", 0.18, 15, 50);
    speckle(g, w, h, 28, 6);
  });
}
export function ceilCanvas() {
  return mk(512, 512, (g, w, h) => {
    g.fillStyle = "#4b4e4a";
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(10,10,10,0.7)";
    g.lineWidth = 3;
    g.strokeRect(2, 2, 252, 252);
    g.strokeRect(258, 2, 252, 252);
    g.strokeRect(2, 258, 252, 252);
    g.strokeRect(258, 258, 252, 252);
    blotches(g, w, h, 50, 31, "25,22,16", 0.5, 25, 90);
    blotches(g, w, h, 20, 32, "100,70,30", 0.25, 25, 70);
    speckle(g, w, h, 20, 33);
  });
}
export function grilleCanvas() {
  return mk(128, 128, (g, w, h) => {
    g.fillStyle = "#2a2b2a";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 14; i++) {
      g.fillStyle = "#0a0a0a";
      g.fillRect(8, 8 + i * 8, w - 16, 4);
      g.fillStyle = "rgba(120,120,115,0.4)";
      g.fillRect(8, 12 + i * 8, w - 16, 1);
    }
    g.strokeStyle = "#555";
    g.lineWidth = 4;
    g.strokeRect(2, 2, w - 4, h - 4);
  });
}
export function crackCanvas() {
  return mk(256, 256, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    const r = rng(77);
    g.strokeStyle = "rgba(235,240,245,0.75)";
    g.lineWidth = 1.2;
    const cx = 150,
      cy = 100;
    for (let i = 0; i < 11; i++) {
      let a = (i / 11) * 6.28 + r() * 0.3,
        x = cx,
        y = cy;
      g.beginPath();
      g.moveTo(x, y);
      for (let s = 0; s < 8; s++) {
        a += (r() - 0.5) * 0.5;
        x += Math.cos(a) * (14 + r() * 16);
        y += Math.sin(a) * (14 + r() * 16);
        g.lineTo(x, y);
      }
      g.stroke();
    }
    for (let k = 1; k < 5; k++) {
      g.beginPath();
      for (let i = 0; i <= 14; i++) {
        const a = (i / 14) * 6.28;
        const rr = k * 18 * (0.8 + r() * 0.4);
        g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
      }
      g.stroke();
    }
  });
}
export function glassCanvas() {
  return mk(128, 128, (g, w, h) => {
    g.fillStyle = "rgba(90,105,110,0.08)";
    g.fillRect(0, 0, w, h);
    blotches(g, w, h, 18, 41, "170,180,180", 0.25, 10, 40);
  });
}
export function rustDecalCanvas() {
  return mk(128, 256, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    const r = rng(55);
    for (let i = 0; i < 9; i++) {
      const x = 20 + r() * 88;
      const gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, "rgba(100,50,20,0.5)");
      gr.addColorStop(1, "rgba(60,30,15,0)");
      g.fillStyle = gr;
      g.fillRect(x, 0, 2 + r() * 6, h * (0.4 + r() * 0.6));
    }
    blotches(g, w, 90, 8, 56, "90,45,18", 0.5, 15, 40);
  });
}
export function labelCanvas(lines: string[], w = 512, h = 256, o: any = {}) {
  return mk(w, h, (g) => {
    g.fillStyle = o.bg || "#c9bc96";
    g.fillRect(0, 0, w, h);
    if (o.bg !== "transparent") {
      blotches(g, w, h, 14, 91, "90,60,20", 0.35, 20, 70);
      speckle(g, w, h, 14, 92);
    }
    g.fillStyle = o.fg || "#2a2217";
    g.textAlign = o.align || "center";
    g.textBaseline = "middle";
    const fs = o.size || Math.min(h / (lines.length + 1), w / 14);
    lines.forEach((l, i) => {
      g.font = `${o.weight || "bold"} ${fs}px ${o.font || "Courier New, monospace"}`;
      const y = (h * (i + 1)) / (lines.length + 1);
      g.fillText(l, o.align === "left" ? 24 : w / 2, y, w - 30);
    });
    if (o.border) {
      g.strokeStyle = o.border;
      g.lineWidth = 6;
      g.strokeRect(3, 3, w - 6, h - 6);
    }
  });
}

export function drawSymbol(g: CanvasRenderingContext2D, name: string, cx: number, cy: number, r: number, col: string, lw = 0) {
  g.save();
  g.fillStyle = col;
  g.strokeStyle = col;
  g.lineWidth = lw || r * 0.18;
  g.lineJoin = "round";
  g.beginPath();
  if (name === "moon") {
    g.arc(cx, cy, r, 0, Math.PI * 2);
    g.fill();
    g.globalCompositeOperation = "destination-out";
    g.beginPath();
    g.arc(cx + r * 0.5, cy - r * 0.2, r * 0.85, 0, Math.PI * 2);
    g.fill();
  } else if (name === "triangle") {
    g.moveTo(cx, cy - r);
    g.lineTo(cx + r * 0.95, cy + r * 0.75);
    g.lineTo(cx - r * 0.95, cy + r * 0.75);
    g.closePath();
    g.stroke();
  } else if (name === "star") {
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const rr = i % 2 ? r * 0.42 : r;
      g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
    }
    g.closePath();
    g.fill();
  } else if (name === "diamond") {
    g.moveTo(cx, cy - r * 1.1);
    g.lineTo(cx + r * 0.75, cy);
    g.lineTo(cx, cy + r * 1.1);
    g.lineTo(cx - r * 0.75, cy);
    g.closePath();
    g.fill();
  } else if (name === "circle") {
    g.arc(cx, cy, r * 0.85, 0, Math.PI * 2);
    g.stroke();
    g.beginPath();
    g.arc(cx, cy, r * 0.25, 0, Math.PI * 2);
    g.fill();
  } else {
    g.rect(cx - r * 0.8, cy - r * 0.8, r * 1.6, r * 1.6);
    g.stroke();
  }
  g.restore();
}

// digit face for decagon wheel
export function digitCanvas(d: number) {
  return mk(128, 96, (g, w, h) => {
    g.fillStyle = "#17120d";
    g.fillRect(0, 0, w, h);
    g.fillStyle = "rgba(200,150,60,0.08)";
    g.fillRect(0, 0, w, 6);
    g.fillStyle = "#e0b560";
    g.font = "bold 78px Courier New, monospace";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(String(d), w / 2, h / 2 + 4);
  });
}
export function symbolFaceCanvas(i: number, powered = true) {
  return mk(128, 128, (g, w, h) => {
    g.fillStyle = "#14161a";
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(160,150,120,0.35)";
    g.lineWidth = 4;
    g.strokeRect(4, 4, w - 8, h - 8);
    drawSymbol(g, SYMS[i], w / 2, h / 2, 40, "#d9c48a", 9);
  });
}

// ---------- newspaper ----------
export const PAGE_W = 960;
export const PAGE_H = 640;
function jitter(k: number, y: number) {
  return Math.sin(y * 0.09 + k * 2.1) * 9 + Math.sin(y * 0.31 + k) * 5 + Math.sin(y * 0.7 + k * 5) * 2.5;
}
export function cutX(k: number, y: number) {
  return (k * PAGE_W) / 3 + jitter(k, y);
}
export function newspaperPage(revealed: boolean) {
  return mk(PAGE_W, PAGE_H, (g, w, h) => {
    g.fillStyle = "#cdbf9a";
    g.fillRect(0, 0, w, h);
    blotches(g, w, h, 30, 61, "110,80,30", 0.3, 30, 120);
    blotches(g, w, h, 10, 62, "40,30,15", 0.25, 30, 90);
    g.fillStyle = "#1e1810";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.font = "bold 58px Georgia, serif";
    g.fillText("THE NIGHT EXPRESS GAZETTE", w / 2, 50);
    g.fillRect(30, 86, w - 60, 4);
    g.font = "italic 20px Georgia, serif";
    g.fillText("Vol. LXIV  ·  Evening Edition  ·  Price 2 Paise", w / 2, 110);
    g.fillRect(30, 126, w - 60, 2);
    g.font = "bold 46px Georgia, serif";
    g.fillText("TRAIN VANISHES INTO THE FOG", w / 2, 175);
    g.font = "italic 22px Georgia, serif";
    g.fillText("Five coaches, one conductor — none returned", w / 2, 212);
    const r = rng(8);
    g.fillStyle = "rgba(30,24,16,0.65)";
    for (let c = 0; c < 6; c++) {
      for (let l = 0; l < 14; l++) {
        const y = 250 + l * 25;
        if (revealed && y > 285 && y < 560) continue;
        g.fillRect(34 + c * 152, y, 100 + r() * 38, 8);
      }
    }
    g.fillStyle = "rgba(30,24,16,0.5)";
    g.fillRect(36, 590, 220, 30);
    g.fillRect(704, 590, 220, 30);
    g.fillStyle = "#1e1810";
    g.font = "bold 20px Georgia, serif";
    g.fillText("— CONTINUED ON PAGE 3 —", w / 2, 606);
    if (revealed) {
      g.save();
      g.fillStyle = "rgba(20,12,4,0.55)";
      g.fillRect(24, 272, w - 48, 300);
      g.shadowColor = "#ffb030";
      g.shadowBlur = 14;
      g.fillStyle = "#ffcf5a";
      g.font = "bold 36px Courier New, monospace";
      g.fillText("CONDUCTOR'S RULE", w / 2, 312);
      g.font = "bold 30px Courier New, monospace";
      g.fillText("(FIRST + SECOND) x THIRD", w / 2, 360);
      g.font = "bold 28px Courier New, monospace";
      g.fillText("ROUTE SIGNS, IN ORDER:", w / 2, 424);
      const xs = [250, 365, 480];
      ["moon", "triangle", "star"].forEach((s, i) => drawSymbol(g, s, xs[i], 484, 30, "#ffcf5a", 7));
      g.font = "bold 26px Courier New, monospace";
      g.fillText("? ?", 640, 484);
      g.font = "bold 22px Courier New, monospace";
      g.fillText("TWO MORE ARE SHOWN ON THE SIGNAL BOARD", w / 2, 540);
      g.restore();
    }
  });
}
export function pieceCanvas(page: HTMLCanvasElement, i: number) {
  const pw = PAGE_W / 3 + 40;
  const ox = (i * PAGE_W) / 3 - 20;
  return mk(Math.round(pw), PAGE_H, (g, w, h) => {
    g.save();
    g.beginPath();
    const left = (y: number) => (i === 0 ? 20 : cutX(i, y) - ox);
    const right = (y: number) => (i === 2 ? w - 20 : cutX(i + 1, y) - ox);
    g.moveTo(left(0), 0);
    for (let y = 0; y <= h; y += 4) g.lineTo(left(y), y);
    for (let y = h; y >= 0; y -= 4) g.lineTo(right(y), y);
    g.closePath();
    g.clip();
    g.drawImage(page, -ox, 0);
    g.restore();
    g.strokeStyle = "rgba(60,40,15,0.55)";
    g.lineWidth = 3;
    g.beginPath();
    for (let y = 0; y <= h; y += 4) (y ? g.lineTo : g.moveTo).call(g, right(y), y);
    g.stroke();
    g.beginPath();
    for (let y = 0; y <= h; y += 4) (y ? g.lineTo : g.moveTo).call(g, left(y), y);
    g.stroke();
  });
}

// ---------- hotbar icons ----------
const iconCache: Record<string, string> = {};
export function itemIcon(id: string): string {
  if (iconCache[id]) return iconCache[id];
  const c = mk(96, 96, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    g.lineJoin = "round";
    if (id === "key") {
      g.strokeStyle = "#d9a441";
      g.fillStyle = "#d9a441";
      g.lineWidth = 9;
      g.beginPath();
      g.arc(30, 36, 16, 0, 7);
      g.stroke();
      g.fillRect(40, 44, 44, 9);
      g.fillRect(66, 52, 8, 16);
      g.fillRect(78, 52, 8, 12);
    } else if (id.startsWith("news")) {
      const k = +id.slice(4) - 1;
      g.fillStyle = "#cdbf9a";
      g.beginPath();
      g.moveTo(22, 12);
      for (let y = 12; y <= 84; y += 6) g.lineTo(70 + ((y * 7 + k * 13) % 9) - 4, y);
      g.lineTo(22 + 4, 84);
      g.closePath();
      g.fill();
      g.fillStyle = "rgba(30,24,16,0.7)";
      for (let i = 0; i < 6; i++) g.fillRect(28, 20 + i * 10, 28 + ((i * k * 7) % 14), 4);
      g.fillStyle = "#1e1810";
      g.font = "bold 14px Georgia";
      g.fillText("N" + (k + 1), 30, 80);
    } else if (id === "screwdriver") {
      g.save();
      g.translate(48, 48);
      g.rotate(-0.8);
      g.fillStyle = "#b72b24";
      g.fillRect(-10, -40, 20, 40);
      g.fillStyle = "#7a1a16";
      g.fillRect(-10, -40, 20, 6);
      g.fillStyle = "#aeb4b8";
      g.fillRect(-3.5, 0, 7, 36);
      g.fillStyle = "#808589";
      g.fillRect(-5, 34, 10, 5);
      g.restore();
    } else if (id === "ticket") {
      g.fillStyle = "#c9b88a";
      g.fillRect(12, 26, 72, 44);
      g.fillStyle = "#4a3820";
      g.fillRect(22, 36, 40, 5);
      g.fillRect(22, 48, 52, 4);
      g.fillRect(22, 58, 26, 4);
      g.fillStyle = "#8a2a20";
      g.beginPath();
      g.arc(70, 38, 6, 0, 7);
      g.fill();
    } else {
      g.fillStyle = "#b8a37a";
      g.beginPath();
      g.moveTo(26, 20);
      g.lineTo(70, 20);
      g.lineTo(70, 76);
      g.lineTo(26, 76);
      g.closePath();
      g.fill();
      g.fillStyle = "#222";
      g.beginPath();
      g.arc(48, 30, 5, 0, 7);
      g.fill();
      g.fillStyle = "#4a3820";
      for (let i = 0; i < 4; i++) g.fillRect(34, 42 + i * 8, 28, 3);
      g.strokeStyle = "#999";
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(48, 25);
      g.quadraticCurveTo(70, 8, 80, 18);
      g.stroke();
    }
  });
  return (iconCache[id] = c.toDataURL());
}
