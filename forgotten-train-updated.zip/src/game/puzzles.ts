// @ts-nocheck
// Four close-up mechanical puzzles. Each one is a separate Three.js object group mounted on a compartment wall
// (never part of the train GLB). Local frame: wall plane at z=0, front faces +z, +x is the viewer's right.
import * as THREE from "three";
import * as TX from "./textures";
import { makeProp } from "./world";

export interface PCtx {
  F: any;
  audio: any;
  M: any;
  toast(t: string, kind?: string): void;
  hasSelected(id: string): boolean;
  hasItem(id: string): boolean;
  consumeItem(id: string): void;
  save(): void;
  onSolved(name: string): void;
  surge(): void;
  spark(p: THREE.Vector3): void;
}

const std = (c: number, o: any = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.55, metalness: 0.6, envMapIntensity: 0.6, ...o });
const ease = (t: number) => t * t * (3 - 2 * t);
function hitPlane(w: number, h: number) {
  return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
}
function box(w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0) {
  const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  o.position.set(x, y, z);
  return o;
}
function arrow(up: boolean, m: THREE.Material) {
  const a = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.06, 3), m);
  a.rotation.x = Math.PI / 2;
  a.rotation.z = up ? Math.PI : 0;
  a.rotation.set(Math.PI / 2, 0, 0);
  const g = new THREE.Group();
  const holder = new THREE.Group();
  holder.add(a);
  holder.rotation.z = up ? Math.PI : 0;
  g.add(holder);
  return g;
}

export abstract class Puzzle {
  group = new THREE.Group();
  pick: THREE.Mesh[] = [];
  title = "";
  camLocal = new THREE.Vector3(0, 1.85, 1.9);
  lookLocal = new THREE.Vector3(0, 1.85, 0);
  constructor(public c: PCtx) {}
  abstract hint(): string;
  enter() {}
  exit() {}
  update(dt: number, t: number) {}
  protected tap(m: THREE.Mesh, fn: () => void) {
    m.userData.tap = fn;
    this.pick.push(m);
    return m;
  }
  camWorld() {
    this.group.updateMatrixWorld(true);
    return { pos: this.group.localToWorld(this.camLocal.clone()), look: this.group.localToWorld(this.lookLocal.clone()) };
  }
}

// =====================================================================================
export class NewsPuzzle extends Puzzle {
  title = "Evidence Board";
  pieces: THREE.Mesh[] = [];
  slots: THREE.Mesh[] = [];
  full: THREE.Mesh;
  sel = -1;
  fade = 0;
  W = 1.2 / TX.PAGE_W;
  constructor(c: PCtx) {
    super(c);
    const cy = 1.8;
    this.camLocal.set(0, cy, 1.95);
    this.lookLocal.set(0, cy, 0);
    const wood = std(0x2c1f16, { roughness: 0.9, metalness: 0.1 });
    this.group.add(box(1.75, 1.05, 0.05, wood, 0, cy, 0.03));
    this.group.add(box(1.85, 0.05, 0.08, c.M.metal, 0, cy + 0.55, 0.05));
    this.group.add(box(1.85, 0.05, 0.08, c.M.metal, 0, cy - 0.55, 0.05));
    const pinM = std(0x9a2a22, { metalness: 0.2 });
    for (const [x, y] of [[-0.8, 0.45], [0.8, 0.45], [-0.8, -0.45], [0.8, -0.45]]) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 6), pinM);
      p.position.set(x, cy + y, 0.065);
      this.group.add(p);
    }
    const page = TX.newspaperPage(false);
    const pw = ((TX.PAGE_W / 3 + 40) * this.W);
    for (let s = 0; s < 3; s++) {
      const sl = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.8), new THREE.MeshBasicMaterial({ color: 0x120d09, transparent: true, opacity: 0.55 }));
      sl.position.set((s - 1) * 0.4, cy, 0.056);
      this.group.add(sl);
      this.slots.push(sl);
    }
    for (let i = 0; i < 3; i++) {
      const tex = TX.ct(TX.pieceCanvas(page, i));
      const m = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.95, metalness: 0, emissive: 0x2a2418, emissiveMap: tex });
      const p = new THREE.Mesh(new THREE.PlaneGeometry(pw, 0.8), m);
      p.userData.piece = i;
      this.tap(p, () => this.onPiece(i));
      this.pieces.push(p);
      this.group.add(p);
    }
    const ft = TX.ct(TX.newspaperPage(true));
    this.full = new THREE.Mesh(
      new THREE.PlaneGeometry(1.2, 0.8),
      new THREE.MeshBasicMaterial({ map: ft, transparent: true, opacity: 0, depthWrite: false })
    );
    this.full.position.set(0, cy, 0.12);
    this.group.add(this.full);
    this.layout(true);
    if (this.c.F.news.solved) this.fade = 1;
  }
  posOf(piece: number) {
    return this.c.F.news.order.indexOf(piece);
  }
  layout(snap = false) {
    const n = this.c.F.news;
    this.pieces.forEach((p, i) => {
      p.visible = n.placed[i];
      p.userData.tx = (this.posOf(i) - 1) * 0.4;
      p.userData.rz = n.flip[i] ? Math.PI : 0;
      if (snap) {
        p.position.set(p.userData.tx, 1.8, 0.07);
        p.rotation.z = p.userData.rz;
      }
    });
  }
  enter() {
    const n = this.c.F.news;
    let any = false;
    for (let i = 0; i < 3; i++)
      if (!n.placed[i] && this.c.hasItem("news" + (i + 1))) {
        this.c.consumeItem("news" + (i + 1));
        n.placed[i] = true;
        any = true;
      }
    if (any) {
      this.c.audio.paper();
      this.c.toast("You pin the fragments to the board.");
      this.c.save();
    }
    this.sel = -1;
    this.layout(true);
  }
  onPiece(i: number) {
    const n = this.c.F.news;
    if (n.solved) return;
    if (this.sel < 0) {
      this.sel = i;
      this.c.audio.paper();
    } else if (this.sel === i) {
      n.flip[i] ^= 1;
      this.sel = -1;
      this.c.audio.paper();
    } else {
      const a = this.posOf(this.sel),
        b = this.posOf(i);
      n.order[a] = i;
      n.order[b] = this.sel;
      this.sel = -1;
      this.c.audio.paper();
    }
    this.layout();
    this.check();
    this.c.save();
  }
  check() {
    const n = this.c.F.news;
    if (n.placed.every(Boolean) && n.order.join() === "0,1,2" && !n.flip.some(Boolean)) {
      n.solved = true;
      this.sel = -1;
      this.c.audio.solve();
      this.c.toast("The ink reveals a hidden message!", "objective");
      this.c.onSolved("news");
    }
  }
  hint() {
    const n = this.c.F.news;
    if (n.solved) return "Hidden ink revealed: the Conductor's rule and the first three route signs.";
    const miss = n.placed.filter((x: boolean) => !x).length;
    const base = "Tap a piece to select it · tap it again to flip · tap another to swap places.";
    return miss ? `${miss} fragment(s) still missing — search the train.  ${base}` : base;
  }
  update(dt: number) {
    for (const p of this.pieces) {
      p.position.x += (p.userData.tx - p.position.x) * Math.min(1, dt * 12);
      p.rotation.z += (p.userData.rz - p.rotation.z) * Math.min(1, dt * 10);
      const sel = this.sel === p.userData.piece;
      p.position.z += ((sel ? 0.13 : 0.07 + p.userData.piece * 0.002) - p.position.z) * Math.min(1, dt * 12);
      p.position.y += ((sel ? 1.84 : 1.8) - p.position.y) * Math.min(1, dt * 12);
    }
    const target = this.c.F.news.solved ? 1 : 0;
    this.fade += (target - this.fade) * Math.min(1, dt * 1.6);
    this.full.material.opacity = this.fade;
    for (const p of this.pieces) p.material.opacity = 1;
  }
}

// =====================================================================================
export class CalcPuzzle extends Puzzle {
  title = "Conductor's Test";
  wheels: THREE.Group[] = [];
  cur = [0, 0, 0];
  lamp: THREE.Mesh;
  lampMat: THREE.MeshBasicMaterial;
  drawer: THREE.Mesh;
  drawerT = 0;
  flash = 0;
  btn: THREE.Mesh;
  btnPress = 0;
  cy = 1.85;
  constructor(c: PCtx) {
    super(c);
    const cy = this.cy;
    this.camLocal.set(0, cy + 0.1, 2.05);
    this.lookLocal.set(0, cy + 0.1, 0);
    const metal = c.M.metal;
    const body = std(0x24292b, { roughness: 0.6, metalness: 0.8 });
    const g = this.group;
    g.add(box(1.4, 0.9, 0.02, body, 0, cy + 0.1, 0.01));
    g.add(box(1.4, 0.04, 0.32, body, 0, cy + 0.53, 0.16));
    g.add(box(1.4, 0.04, 0.32, body, 0, cy - 0.33, 0.16));
    g.add(box(0.04, 0.9, 0.32, body, -0.68, cy + 0.1, 0.16));
    g.add(box(0.04, 0.9, 0.32, body, 0.68, cy + 0.1, 0.16));
    // front plate pieces around the three windows
    const fz = 0.31;
    g.add(box(1.4, 0.45, 0.03, body, 0, cy + 0.31, fz)); // top strip y cy+0.085..cy+0.535
    g.add(box(1.4, 0.245, 0.03, body, 0, cy - 0.2075, fz)); // bottom strip
    g.add(box(0.29, 0.17, 0.03, body, -0.555, cy, fz));
    g.add(box(0.08, 0.17, 0.03, body, -0.15, cy, fz));
    g.add(box(0.08, 0.17, 0.03, body, 0.15, cy, fz));
    g.add(box(0.29, 0.17, 0.03, body, 0.555, cy, fz));
    // digit faces (decagon wheels)
    const faceMats = [];
    for (let d = 0; d < 10; d++) {
      const t = TX.ct(TX.digitCanvas(d));
      faceMats.push(new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0.55, roughness: 0.5, metalness: 0.3 }));
    }
    const R = 0.2;
    const fh = 2 * R * Math.tan(Math.PI / 10);
    for (let i = 0; i < 3; i++) {
      const w = new THREE.Group();
      w.position.set((i - 1) * 0.3, cy, 0.12);
      for (let d = 0; d < 10; d++) {
        const holder = new THREE.Group();
        holder.rotation.x = (-2 * Math.PI * d) / 10;
        const f = new THREE.Mesh(new THREE.PlaneGeometry(0.205, fh * 1.02), faceMats[d]);
        f.position.z = R;
        holder.add(f);
        w.add(holder);
      }
      w.add(new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.26, 8).rotateZ(Math.PI / 2), metal));
      g.add(w);
      this.wheels.push(w);
      const am = std(0xc8a24a, { emissive: 0x3a2808 });
      for (const up of [true, false]) {
        const ar = arrow(up, am);
        ar.position.set((i - 1) * 0.3, cy + (up ? 0.17 : -0.17), 0.335);
        g.add(ar);
        const h = hitPlane(0.24, 0.15);
        h.position.set((i - 1) * 0.3, cy + (up ? 0.17 : -0.17), 0.345);
        this.tap(h, () => this.turn(i, up ? 1 : -1));
        g.add(h);
      }
    }
    // text plate
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(1.3, 0.36),
      new THREE.MeshStandardMaterial({
        map: TX.ct(TX.labelCanvas(["THE CONDUCTOR'S TEST", "A: 2, 3, 4  =  20", "B: 3, 4, 5  =  35", "C: 4, 5, 6  =  ?"], 640, 180, { bg: "#14110c", fg: "#e0b560", size: 30, border: "#6a5428" })),
        emissive: 0xffffff,
        emissiveIntensity: 0.4,
        roughness: 0.6,
      })
    );
    plate.material.emissiveMap = plate.material.map;
    plate.position.set(0, cy + 0.36, 0.33);
    g.add(plate);
    // answer button + lamp
    this.btn = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.04, 16).rotateX(Math.PI / 2), std(0xa11b16, { emissive: 0x300503, roughness: 0.4 }));
    this.btn.position.set(0.555, cy - 0.02, 0.335);
    g.add(this.btn);
    const bh = hitPlane(0.2, 0.2);
    bh.position.set(0.555, cy, 0.36);
    this.tap(bh, () => this.press());
    g.add(bh);
    this.lampMat = new THREE.MeshBasicMaterial({ color: 0x551008 });
    this.lamp = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), this.lampMat);
    this.lamp.position.set(0.555, cy + 0.13, 0.34);
    g.add(this.lamp);
    // little "ENTER" label
    const lb = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.05), new THREE.MeshBasicMaterial({ map: TX.ct(TX.labelCanvas(["ENTER"], 128, 32, { bg: "#24292b", fg: "#c8a24a", size: 22 })) }));
    lb.position.set(0.555, cy - 0.12, 0.326);
    g.add(lb);
    // drawer containing the screwdriver
    this.drawer = box(0.7, 0.05, 0.32, std(0x2d3234, { roughness: 0.6 }), -0.35, cy - 0.375, 0.16);
    g.add(this.drawer);
    this.drawer.add(box(0.7, 0.07, 0.02, std(0x3a3f41), 0, 0.0, 0.16));
    const knob = box(0.1, 0.02, 0.03, c.M.brass, 0, 0, 0.185);
    this.drawer.add(knob);
    if (c.F.calc.solved) this.drawerT = 1;
    c.F.calc.wheels.forEach((v: number, i: number) => {
      this.cur[i] = v;
      this.wheels[i].rotation.x = (2 * Math.PI * v) / 10;
    });
    this.setLamp(c.F.calc.solved ? 0x2cff60 : 0x551008);
  }
  setLamp(col: number) {
    this.lampMat.color.setHex(col);
  }
  drawerItemWorld() {
    this.group.updateMatrixWorld(true);
    return this.group.localToWorld(new THREE.Vector3(-0.35, this.cy - 0.34, 0.32 + 0.12));
  }
  turn(i: number, d: number) {
    if (this.c.F.calc.solved) return;
    this.c.F.calc.wheels[i] += d;
    this.c.audio.wheel();
    this.c.save();
  }
  press() {
    if (this.c.F.calc.solved) return;
    this.btnPress = 1;
    this.c.audio.button();
    const w = this.c.F.calc.wheels.map((v: number) => ((v % 10) + 10) % 10);
    if (w[0] === 0 && w[1] === 5 && w[2] === 4) {
      this.c.F.calc.solved = true;
      this.setLamp(0x2cff60);
      this.c.audio.solve();
      setTimeout(() => this.c.audio.unlock(), 500);
      this.c.toast("Correct. Something unlocks inside the console.", "objective");
      this.c.onSolved("calc");
    } else {
      this.flash = 1;
      this.c.audio.error();
      this.c.toast("Wrong answer. The mechanism stays locked.");
    }
  }
  hint() {
    if (this.c.F.calc.solved) return "Answer 054 accepted. The drawer opened and the door ahead is unlocked.";
    const rule = this.c.F.news.solved ? "Newspaper rule: (first + second) × third." : "The rule is not written here — a torn newspaper may explain it.";
    return `Find C. Tap arrows to turn the wheels, then press the red button.  ${rule}`;
  }
  update(dt: number, t: number) {
    this.wheels.forEach((w, i) => {
      const target = (2 * Math.PI * this.c.F.calc.wheels[i]) / 10;
      this.cur[i] += 0; // keep
      w.rotation.x += (target - w.rotation.x) * Math.min(1, dt * 11);
    });
    this.drawerT += ((this.c.F.calc.solved ? 1 : 0) - this.drawerT) * Math.min(1, dt * 1.6);
    this.drawer.position.z = 0.16 + ease(Math.min(this.drawerT, 1)) * 0.3;
    this.btnPress = Math.max(0, this.btnPress - dt * 5);
    this.btn.position.z = 0.335 - this.btnPress * 0.02;
    if (this.flash > 0) {
      this.flash = Math.max(0, this.flash - dt * 2);
      this.setLamp(Math.floor(t * 14) % 2 ? 0xff2010 : 0x551008);
      if (this.flash === 0) this.setLamp(0x551008);
    }
  }
}

// =====================================================================================
const WIRE_COL = [0xd02a22, 0xe0b81c, 0x2a5fd8]; // red, yellow, blue
const WIRE_NAME = ["red", "yellow", "blue"];
export const WIRE_ORDER = [0, 2, 1]; // red -> blue -> yellow
export class PanelPuzzle extends Puzzle {
  title = "Maintenance Panel";
  cover = new THREE.Group();
  screws: THREE.Group[] = [];
  screwHits: THREE.Mesh[] = [];
  lever = new THREE.Group();
  bridges: THREE.Mesh[] = [];
  lampMat = new THREE.MeshBasicMaterial({ color: 0xff2010 });
  driver: THREE.Group;
  driverInner: THREE.Object3D;
  anim: any = null;
  coverFall = 0;
  cy = 1.85;
  wireHits: THREE.Mesh[] = [];
  leverHit: THREE.Mesh;
  constructor(c: PCtx) {
    super(c);
    const cy = this.cy;
    this.camLocal.set(0, cy, 1.8);
    this.lookLocal.set(0, cy, 0);
    const g = this.group;
    const body = std(0x30383b, { roughness: 0.7, metalness: 0.7 });
    const dark = std(0x0d0e0f, { roughness: 0.9 });
    g.add(box(1.0, 0.8, 0.02, dark, 0, cy, 0.01));
    g.add(box(1.0, 0.04, 0.14, body, 0, cy + 0.38, 0.07));
    g.add(box(1.0, 0.04, 0.14, body, 0, cy - 0.38, 0.07));
    g.add(box(0.04, 0.8, 0.14, body, -0.48, cy, 0.07));
    g.add(box(0.04, 0.8, 0.14, body, 0.48, cy, 0.07));
    // interior: lever
    g.add(box(0.14, 0.26, 0.03, std(0x1c2022), -0.3, cy + 0.15, 0.04));
    this.lever.position.set(-0.3, cy + 0.15, 0.06);
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.14, 8).rotateX(Math.PI / 2), c.M.metal);
    rod.position.z = 0.07;
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), std(0xb01c18, { metalness: 0.2 }));
    knob.position.z = 0.15;
    this.lever.add(rod, knob);
    g.add(this.lever);
    this.leverHit = hitPlane(0.2, 0.34);
    this.leverHit.position.set(-0.3, cy + 0.1, 0.17);
    g.add(this.tap(this.leverHit, () => this.onLever()));
    const lb = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.06), new THREE.MeshBasicMaterial({ map: TX.ct(TX.labelCanvas(["MAIN BREAKER"], 192, 48, { bg: "#c9bc96", size: 22 })) }));
    lb.position.set(-0.3, cy - 0.06, 0.056);
    g.add(lb);
    // wires
    const rows = [cy + 0.2, cy + 0.07, cy - 0.06];
    for (let w = 0; w < 3; w++) {
      const col = WIRE_COL[w];
      const wm = std(col, { roughness: 0.6, metalness: 0.1, emissive: col, emissiveIntensity: 0.12 });
      const y = rows[w];
      for (const x of [-0.1, 0.2]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.05, 10).rotateX(Math.PI / 2), c.M.brass);
        post.position.set(x, y, 0.05);
        g.add(post);
      }
      for (const [x0, x1] of [[-0.1, -0.03], [0.13, 0.2]]) {
        const st = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, x1 - x0, 6).rotateZ(Math.PI / 2), wm);
        st.position.set((x0 + x1) / 2, y, 0.06);
        g.add(st);
      }
      const br = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.16, 6).rotateZ(Math.PI / 2), wm);
      br.position.set(0.05, y, 0.065);
      br.visible = false;
      g.add(br);
      this.bridges.push(br);
      const h = hitPlane(0.34, 0.1);
      h.position.set(0.05, y, 0.14);
      this.tap(h, () => this.onWire(w));
      g.add(h);
      this.wireHits.push(h);
    }
    // lamp
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 10), this.lampMat);
    lamp.position.set(0.38, cy + 0.22, 0.06);
    g.add(lamp);
    // repair log
    const log = new THREE.Mesh(
      new THREE.PlaneGeometry(0.86, 0.22),
      new THREE.MeshStandardMaterial({
        map: TX.ct(TX.labelCanvas(["REPAIR LOG", "1. Main breaker DOWN (off)", "2. Wires: RED, then BLUE, then YELLOW", "3. Main breaker UP (on)"], 688, 176, { size: 26, align: "left" })),
        roughness: 1,
      })
    );
    log.position.set(0, cy - 0.27, 0.045);
    g.add(log);
    // cover with screws
    this.cover.position.set(0, cy, 0.145);
    this.cover.add(box(1.0, 0.8, 0.02, body, 0, 0, 0));
    this.cover.add(box(0.8, 0.12, 0.005, std(0xaa2418, { roughness: 0.7, metalness: 0.2 }), 0, 0.12, 0.012));
    const warn = new THREE.Mesh(new THREE.PlaneGeometry(0.76, 0.5), new THREE.MeshBasicMaterial({ map: TX.ct(TX.labelCanvas(["DANGER  415 V", "AUTHORISED STAFF ONLY", "ISOLATE BEFORE OPENING"], 512, 256, { bg: "transparent", fg: "#e8d9a8", size: 34 })), transparent: true }));
    warn.position.set(0, -0.05, 0.016);
    this.cover.add(warn);
    g.add(this.cover);
    const sm = std(0xa0a6a8, { roughness: 0.35, metalness: 0.95 });
    [[-0.42, 0.32], [0.42, 0.32], [-0.42, -0.32], [0.42, -0.32]].forEach(([x, y], i) => {
      const s = new THREE.Group();
      s.position.set(x, cy + y, 0.16);
      s.add(new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.036, 0.022, 14).rotateX(Math.PI / 2), sm));
      s.add(box(0.05, 0.008, 0.006, c.M.dark, 0, 0, 0.012));
      s.add(box(0.008, 0.05, 0.006, c.M.dark, 0, 0, 0.012));
      g.add(s);
      this.screws.push(s);
      const h = hitPlane(0.16, 0.16);
      h.position.set(x, cy + y, 0.2);
      this.tap(h, () => this.onScrew(i));
      g.add(h);
      this.screwHits.push(h);
    });
    const prop = makeProp("screwdriver", c.M);
    prop.getObjectByName("sparkle")?.removeFromParent();
    prop.scale.setScalar(3.2);
    this.driverInner = prop;
    this.driver = new THREE.Group();
    this.driver.add(prop);
    this.driver.visible = false;
    g.add(this.driver);
    this.refresh(true);
  }
  coverOff() {
    return this.c.F.panel.screws.every((s: number) => !s);
  }
  refresh(snap = false) {
    const P = this.c.F.panel;
    P.screws.forEach((s: number, i: number) => {
      this.screws[i].visible = !!s;
      this.screwHits[i].visible = !!s;
    });
    const off = this.coverOff();
    if (snap) {
      this.cover.visible = !off;
      this.coverFall = off ? 1 : 0;
    }
    // hit areas of cover-covered parts only active after cover is off
    this.wireHits.forEach((h) => (h.visible = off));
    this.leverHit.visible = off;
    this.lever.rotation.x = P.breaker ? -0.6 : 0.6;
    this.bridges.forEach((b, w) => (b.visible = P.seq.includes(w)));
    this.lampMat.color.setHex(P.done ? 0x2cff60 : 0xff2010);
  }
  onScrew(i: number) {
    const P = this.c.F.panel;
    if (this.anim || !P.screws[i]) return;
    if (!this.c.hasSelected("screwdriver")) {
      this.c.audio.locked();
      this.c.toast("The screws won't budge by hand. Select the screwdriver in your hotbar.");
      return;
    }
    this.anim = { type: "screw", i, t: 0 };
    this.driver.visible = true;
    this.c.audio.screwdriver();
  }
  onLever() {
    const P = this.c.F.panel;
    if (this.anim || P.done) return;
    P.breaker = !P.breaker;
    this.c.audio.switch();
    this.refresh();
    if (P.breaker) {
      if (P.seq.length === 3) {
        P.done = true;
        this.c.audio.powerUp();
        this.lampMat.color.setHex(0x2cff60);
        this.c.toast("Power restored. Somewhere ahead, a system hums to life.", "objective");
        this.c.surge();
        this.c.onSolved("panel");
      } else {
        this.c.toast("The breaker is on, but the circuit is incomplete.");
      }
    }
    this.c.save();
  }
  onWire(w: number) {
    const P = this.c.F.panel;
    if (this.anim || P.done || P.seq.includes(w)) return;
    const wp = new THREE.Vector3(0.05, [this.cy + 0.2, this.cy + 0.07, this.cy - 0.06][w], 0.1);
    this.group.updateMatrixWorld(true);
    if (P.breaker) {
      this.c.audio.zap();
      this.c.spark(this.group.localToWorld(wp));
      this.c.surge();
      P.seq = [];
      this.refresh();
      this.c.toast("ZAP! The breaker is still live. Switch it off first.");
      return;
    }
    if (WIRE_ORDER[P.seq.length] === w) {
      P.seq.push(w);
      this.c.audio.button();
      this.c.toast(`The ${WIRE_NAME[w]} wire clamps on.`);
    } else {
      P.seq = [];
      this.c.audio.error();
      this.c.audio.zap();
      this.c.spark(this.group.localToWorld(wp));
      this.c.toast("Wrong order — the wires spring loose. Check the repair log.");
    }
    this.refresh();
    this.c.save();
  }
  hint() {
    const P = this.c.F.panel;
    if (P.done) return "Circuit restored. The route display and the final mechanism now have power.";
    if (!this.coverOff()) return "Select the screwdriver (hotbar) and tap each screw.";
    if (P.breaker && P.seq.length === 0) return "Read the repair log. The main breaker is live — tap the lever.";
    if (!P.breaker && P.seq.length < 3) return `Tap the broken wires in the right order (${P.seq.length}/3 connected).`;
    return "Tap the main breaker lever to restore power.";
  }
  update(dt: number) {
    const a = this.anim;
    if (a && a.type === "screw") {
      a.t += dt;
      const s = this.screws[a.i];
      const k = Math.min(a.t / 1.0, 1);
      // driver sits on the screw, turns it, screw backs out
      this.driver.rotation.set(0, Math.PI / 2, 0);
      this.driverInner.rotation.x = a.t * 14;
      this.driver.position.set(s.position.x, s.position.y, 0.2 + 0.34 + ease(k) * 0.04);
      s.rotation.z = -a.t * 14;
      s.position.z = 0.16 + ease(k) * 0.04;
      if (a.t >= 1.0) {
        this.c.F.panel.screws[a.i] = 0;
        this.driver.visible = false;
        this.anim = null;
        this.c.audio.paper();
        if (this.coverOff()) {
          this.anim = { type: "cover", t: 0 };
          this.c.audio.thud();
          this.c.toast("The cover plate clatters to the floor.");
        }
        this.refresh();
        this.c.save();
      }
    }
    if (this.anim && this.anim.type === "cover") {
      this.anim.t += dt;
      const k = Math.min(this.anim.t / 0.9, 1);
      this.cover.rotation.x = k * k * 1.3;
      this.cover.position.y = this.cy - k * k * 0.5;
      this.cover.position.z = 0.145 + k * 0.2;
      if (k >= 1) {
        this.cover.visible = false;
        this.anim = null;
        this.refresh();
      }
    }
  }
  exit() {
    this.driver.visible = false;
    if (this.anim && this.anim.type === "screw") {
      this.anim = null;
    }
  }
}

// =====================================================================================
export const SOLUTION = [0, 1, 2, 3, 4]; // moon, triangle, star, diamond, circle
export class MachinePuzzle extends Puzzle {
  title = "Signal Lock";
  rings: THREE.Group[] = [];
  faceMats: THREE.MeshStandardMaterial[] = [];
  lampMat = new THREE.MeshBasicMaterial({ color: 0x551008 });
  powerMat = new THREE.MeshBasicMaterial({ color: 0x3a2a08 });
  bar: THREE.Mesh;
  barT = 0;
  cy = 1.75;
  constructor(c: PCtx) {
    super(c);
    const cy = this.cy;
    this.camLocal.set(0, cy + 0.05, 2.05);
    this.lookLocal.set(0, cy + 0.05, 0);
    const g = this.group;
    const body = std(0x2a2f31, { roughness: 0.65, metalness: 0.8 });
    g.add(box(1.5, 1.05, 0.02, body, 0, cy + 0.02, 0.01));
    g.add(box(1.5, 0.05, 0.32, body, 0, cy + 0.545, 0.16));
    g.add(box(1.5, 0.05, 0.32, body, 0, cy - 0.505, 0.16));
    g.add(box(0.05, 1.05, 0.32, body, -0.725, cy + 0.02, 0.16));
    g.add(box(0.05, 1.05, 0.32, body, 0.725, cy + 0.02, 0.16));
    const fz = 0.31;
    g.add(box(1.5, 0.39, 0.03, body, 0, cy + 0.325, fz));
    g.add(box(1.5, 0.39, 0.03, body, 0, cy - 0.285, fz));
    for (let i = 0; i <= 5; i++) g.add(box(0.025, 0.22, 0.03, body, (i - 2.5) * 0.28, cy + 0.02, fz));
    // symbol faces
    for (let s = 0; s < 6; s++) {
      const t = TX.ct(TX.symbolFaceCanvas(s));
      this.faceMats.push(new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.5, metalness: 0.4 }));
    }
    const R = 0.15;
    const fh = 2 * R * Math.tan(Math.PI / 6);
    for (let i = 0; i < 5; i++) {
      const w = new THREE.Group();
      w.position.set((i - 2) * 0.28, cy + 0.02, 0.14);
      for (let s = 0; s < 6; s++) {
        const h = new THREE.Group();
        h.rotation.x = (-2 * Math.PI * s) / 6;
        const f = new THREE.Mesh(new THREE.PlaneGeometry(0.245, fh * 1.02), this.faceMats[s]);
        f.position.z = R;
        h.add(f);
        w.add(h);
      }
      w.add(new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.27, 8).rotateZ(Math.PI / 2), c.M.metal));
      g.add(w);
      this.rings.push(w);
      const am = std(0xc8a24a, { emissive: 0x3a2808 });
      for (const up of [true, false]) {
        const ar = arrow(up, am);
        ar.position.set((i - 2) * 0.28, cy + 0.02 + (up ? 0.2 : -0.2), 0.335);
        g.add(ar);
        const h = hitPlane(0.26, 0.16);
        h.position.set((i - 2) * 0.28, cy + 0.02 + (up ? 0.2 : -0.2), 0.345);
        this.tap(h, () => this.turn(i, up ? 1 : -1));
        g.add(h);
      }
    }
    // title plate + lamps
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.12), new THREE.MeshBasicMaterial({ map: TX.ct(TX.labelCanvas(["S I G N A L   L O C K"], 360, 48, { bg: "#1a1d1f", fg: "#b9a56c", size: 26, border: "#4a4430" })) }));
    plate.position.set(-0.2, cy + 0.43, 0.327);
    g.add(plate);
    const l1 = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), this.powerMat);
    l1.position.set(0.5, cy + 0.43, 0.335);
    const l2 = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), this.lampMat);
    l2.position.set(0.6, cy + 0.43, 0.335);
    g.add(l1, l2);
    // locking bar
    this.bar = box(1.3, 0.06, 0.05, c.M.rust, 0, cy - 0.43, 0.335);
    g.add(this.bar);
    g.add(box(0.1, 0.12, 0.07, c.M.metal, -0.68, cy - 0.43, 0.335));
    g.add(box(0.1, 0.12, 0.07, c.M.metal, 0.68, cy - 0.43, 0.335));
    c.F.machine.cont.forEach((v: number, i: number) => (this.rings[i].rotation.x = (2 * Math.PI * v) / 6));
    if (c.F.machine.solved) this.barT = 1;
    this.syncPower();
  }
  powered() {
    return this.c.F.panel.done;
  }
  syncPower() {
    const on = this.powered();
    this.faceMats.forEach((m) => (m.emissiveIntensity = on ? 0.5 : 0));
    this.powerMat.color.setHex(on ? 0xffb030 : 0x3a2a08);
    this.lampMat.color.setHex(this.c.F.machine.solved ? 0x2cff60 : 0x551008);
  }
  turn(i: number, d: number) {
    const M = this.c.F.machine;
    if (M.solved) return;
    if (!this.powered()) {
      this.c.audio.error();
      this.c.toast("The mechanism is dead. Its power has been cut.");
      return;
    }
    M.cont[i] += d;
    this.c.audio.wheel();
    const ok = M.cont.every((v: number, k: number) => ((v % 6) + 6) % 6 === SOLUTION[k]);
    if (ok) {
      M.solved = true;
      this.lampMat.color.setHex(0x2cff60);
      setTimeout(() => {
        this.c.audio.solve();
        this.c.audio.unlock();
      }, 450);
      this.c.toast("The lock disengages. The exit door is unbolted.", "objective");
      this.c.onSolved("machine");
    }
    this.c.save();
  }
  hint() {
    const M = this.c.F.machine;
    if (M.solved) return "The locking bar has retracted. The exit is open.";
    if (!this.powered()) return "The rings are dead and cold. Restore power in the maintenance car first.";
    return "Set the five rings to the route signs in order. Arrows turn each ring.";
  }
  update(dt: number) {
    this.rings.forEach((r, i) => {
      const t = (2 * Math.PI * this.c.F.machine.cont[i]) / 6;
      r.rotation.x += (t - r.rotation.x) * Math.min(1, dt * 11);
    });
    this.syncPower();
    this.barT += ((this.c.F.machine.solved ? 1 : 0) - this.barT) * Math.min(1, dt * 1.5);
    this.bar.position.x = ease(Math.min(1, this.barT)) * 0.0;
    this.bar.scale.x = 1 - ease(Math.min(1, this.barT)) * 0.85;
    this.bar.position.x = -ease(Math.min(1, this.barT)) * 0.55;
  }
}
