import { useSyncExternalStore } from "react";

export type Quality = "low" | "medium" | "high";
export interface Settings {
  master: number;
  sfx: number;
  music: number;
  sens: number;
  quality: Quality;
}
export interface UIState {
  screen: "loading" | "menu" | "playing" | "paused" | "settings" | "credits" | "ending";
  settingsFrom: "menu" | "pause";
  loadPct: number;
  loadErr: string | null;
  assetsReady: boolean;
  hasSave: boolean;
  hotbar: (string | null)[];
  selected: number;
  prompt: { text: string; sub?: string; actionable: boolean } | null;
  toast: { id: number; text: string; kind: "item" | "info" | "objective" } | null;
  flashlight: boolean;
  puzzle: { title: string; hint: string } | null;
  note: { title: string; body: string; img?: string } | null;
  settings: Settings;
  fade: number; // 0..1 white fade
}

const SKEY = "forgotten_train_settings_v1";
function loadSettings(): Settings {
  const def: Settings = { master: 0.85, sfx: 0.9, music: 0.5, sens: 1, quality: "medium" };
  try {
    const raw = localStorage.getItem(SKEY);
    if (raw) return { ...def, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return def;
}

let state: UIState = {
  screen: "loading",
  settingsFrom: "menu",
  loadPct: 0,
  loadErr: null,
  assetsReady: false,
  hasSave: false,
  hotbar: [null, null, null, null, null],
  selected: 0,
  prompt: null,
  toast: null,
  flashlight: false,
  puzzle: null,
  note: null,
  settings: loadSettings(),
  fade: 0,
};
const listeners = new Set<() => void>();

export const ui = {
  get: () => state,
  set(p: Partial<UIState>) {
    state = { ...state, ...p };
    listeners.forEach((l) => l());
  },
  saveSettings() {
    try {
      localStorage.setItem(SKEY, JSON.stringify(state.settings));
    } catch {
      /* ignore */
    }
  },
  subscribe(l: () => void) {
    listeners.add(l);
    return () => listeners.delete(l);
  },
};

export function useUI<T>(sel: (s: UIState) => T): T {
  return useSyncExternalStore(ui.subscribe, () => sel(state));
}
