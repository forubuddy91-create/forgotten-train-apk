// @ts-nocheck
// Fully procedural layered horror audio (WebAudio). No external files needed.
export class AudioSys {
  ctx: AudioContext | null = null;
  master: GainNode;
  sfx: GainNode;
  music: GainNode;
  amb: GainNode;
  noiseBuf: AudioBuffer;
  started = false;
  vol = { master: 0.85, sfx: 0.9, music: 0.5 };
  musicTimer = 4;
  lp = { x: 0, y: 0, z: 0 };

  init() {
    if (this.started) {
      this.ctx!.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    const c = (this.ctx = new AC());
    this.master = c.createGain();
    this.sfx = c.createGain();
    this.music = c.createGain();
    this.amb = c.createGain();
    this.sfx.connect(this.master);
    this.music.connect(this.master);
    this.amb.connect(this.master);
    const comp = c.createDynamicsCompressor();
    this.master.connect(comp);
    comp.connect(c.destination);
    // noise buffer
    const len = c.sampleRate * 3;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.applyVolumes();
    this.startAmbience();
    this.started = true;
  }
  setVolumes(m: number, s: number, mu: number) {
    this.vol = { master: m, sfx: s, music: mu };
    this.applyVolumes();
  }
  applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.vol.master, t, 0.05);
    this.sfx.gain.setTargetAtTime(this.vol.sfx, t, 0.05);
    this.amb.gain.setTargetAtTime(this.vol.sfx * 0.9, t, 0.05);
    this.music.gain.setTargetAtTime(this.vol.music, t, 0.05);
  }
  suspend() {
    this.ctx?.suspend();
  }
  resume() {
    this.ctx?.resume();
  }
  setListener(x: number, y: number, z: number, fx: number, fz: number) {
    if (!this.ctx) return;
    this.lp = { x, y, z };
    const l = this.ctx.listener as any;
    if (l.positionX) {
      l.positionX.value = x;
      l.positionY.value = y;
      l.positionZ.value = z;
      l.forwardX.value = fx;
      l.forwardY.value = 0;
      l.forwardZ.value = fz;
      l.upX.value = 0;
      l.upY.value = 1;
      l.upZ.value = 0;
    } else if (l.setPosition) {
      l.setPosition(x, y, z);
      l.setOrientation(fx, 0, fz, 0, 1, 0);
    }
  }

  // ---------- helpers ----------
  private out(pos?: number[]): AudioNode {
    if (!pos) return this.sfx;
    const c = this.ctx!;
    const p = c.createPanner();
    p.panningModel = "equalpower";
    p.distanceModel = "inverse";
    p.refDistance = 2;
    p.rolloffFactor = 1.1;
    if ((p as any).positionX) {
      (p as any).positionX.value = pos[0];
      (p as any).positionY.value = pos[1];
      (p as any).positionZ.value = pos[2];
    } else p.setPosition(pos[0], pos[1], pos[2]);
    p.connect(this.sfx);
    return p;
  }
  private n(dest: AudioNode, o: any) {
    const c = this.ctx!;
    const t0 = c.currentTime + (o.when || 0);
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter();
    f.type = o.type || "bandpass";
    f.frequency.setValueAtTime(o.f || 1000, t0);
    if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t0 + o.t);
    f.Q.value = o.q || 1;
    const g = c.createGain();
    const a = o.a || 0.004;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(o.v || 0.3, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.t);
    s.connect(f);
    f.connect(g);
    g.connect(dest);
    s.start(t0, Math.random() * 2);
    s.stop(t0 + o.t + 0.05);
  }
  private tn(dest: AudioNode, o: any) {
    const c = this.ctx!;
    const t0 = c.currentTime + (o.when || 0);
    const os = c.createOscillator();
    os.type = o.type || "sine";
    os.frequency.setValueAtTime(o.f, t0);
    if (o.f2) os.frequency.exponentialRampToValueAtTime(o.f2, t0 + o.t);
    const g = c.createGain();
    const a = o.a || 0.005;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(o.v || 0.2, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.t);
    os.connect(g);
    g.connect(dest);
    os.start(t0);
    os.stop(t0 + o.t + 0.05);
  }
  private ok() {
    return this.ctx && this.started;
  }

  // ---------- ambience ----------
  startAmbience() {
    const c = this.ctx!;
    const loop = (filterType: BiquadFilterType, f: number, q: number, gain: number) => {
      const s = c.createBufferSource();
      s.buffer = this.noiseBuf;
      s.loop = true;
      const fl = c.createBiquadFilter();
      fl.type = filterType;
      fl.frequency.value = f;
      fl.Q.value = q;
      const g = c.createGain();
      g.gain.value = gain;
      s.connect(fl);
      fl.connect(g);
      g.connect(this.amb);
      s.start();
      return { fl, g };
    };
    // distant wind with slow LFO
    const wind = loop("bandpass", 380, 0.5, 0.11);
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.07;
    const lg = c.createGain();
    lg.gain.value = 0.07;
    lfo.connect(lg);
    lg.connect(wind.g.gain);
    const lg2 = c.createGain();
    lg2.gain.value = 160;
    lfo.connect(lg2);
    lg2.connect(wind.fl.frequency);
    lfo.start();
    // low train mechanical rumble
    loop("lowpass", 90, 0.7, 0.55);
    const dr = c.createOscillator();
    dr.type = "sawtooth";
    dr.frequency.value = 48;
    const drf = c.createBiquadFilter();
    drf.type = "lowpass";
    drf.frequency.value = 130;
    const drg = c.createGain();
    drg.gain.value = 0.05;
    dr.connect(drf);
    drf.connect(drg);
    drg.connect(this.amb);
    dr.start();
    // electrical buzz
    const bz = c.createOscillator();
    bz.type = "sawtooth";
    bz.frequency.value = 100;
    const bf = c.createBiquadFilter();
    bf.type = "bandpass";
    bf.frequency.value = 1800;
    bf.Q.value = 3;
    const bg = c.createGain();
    bg.gain.value = 0.006;
    bz.connect(bf);
    bf.connect(bg);
    bg.connect(this.amb);
    bz.start();
  }
  updateMusic(dt: number, tension: number) {
    if (!this.ok()) return;
    this.musicTimer -= dt;
    if (this.musicTimer > 0) return;
    this.musicTimer = 7 + Math.random() * 6;
    const c = this.ctx!;
    const roots = [55, 65.4, 49, 58.3];
    const r = roots[Math.floor(Math.random() * roots.length)];
    const notes = [r, r * 1.5, r * 2 * (tension > 0.5 ? 1.0595 : 1.2), r * 3.0];
    notes.forEach((f, i) => {
      const t0 = c.currentTime + i * 0.4;
      const o = c.createOscillator();
      o.type = i % 2 ? "triangle" : "sine";
      o.frequency.value = f;
      o.detune.value = (Math.random() - 0.5) * 14;
      const fl = c.createBiquadFilter();
      fl.type = "lowpass";
      fl.frequency.value = 600;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(0.09, t0 + 3);
      g.gain.linearRampToValueAtTime(0.0001, t0 + 9);
      o.connect(fl);
      fl.connect(g);
      g.connect(this.music);
      o.start(t0);
      o.stop(t0 + 9.5);
    });
    if (Math.random() < 0.35 + tension * 0.3) this.tn(this.music, { f: 1400, f2: 1250, t: 5, v: 0.012, a: 2.5, when: 2 });
  }

  // ---------- random events (spatial) ----------
  creak(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos);
    const f = 90 + Math.random() * 120;
    this.tn(o, { f, f2: f * (0.7 + Math.random() * 0.8), t: 1.1 + Math.random(), v: 0.08, type: "sawtooth", a: 0.3 });
    this.n(o, { f: 500, f2: 260, q: 6, t: 1.2, v: 0.05, a: 0.3 });
  }
  rattle(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos);
    for (let i = 0; i < 9; i++) this.n(o, { f: 2200 + Math.random() * 1500, q: 2, t: 0.06, v: 0.05 + Math.random() * 0.04, when: i * 0.07 + Math.random() * 0.03 });
    this.n(o, { f: 160, type: "lowpass", t: 0.9, v: 0.15, a: 0.15 });
  }
  distant(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos || [Math.random() * 20 - 10, 1, Math.random() * 30]);
    const k = Math.random();
    if (k < 0.5) {
      this.tn(o, { f: 70, f2: 52, t: 2.4, v: 0.15, a: 0.5 });
      this.tn(o, { f: 140, f2: 104, t: 2.4, v: 0.05, a: 0.5 });
    } else if (k < 0.8) {
      this.n(o, { f: 300, f2: 700, q: 3, t: 1.8, v: 0.06, a: 0.8 });
    } else {
      this.tn(o, { f: 520, f2: 410, t: 1.6, v: 0.025, a: 0.5, type: "triangle" });
    }
  }
  insect(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos);
    for (let i = 0; i < 6; i++) this.n(o, { f: 4200 + Math.random() * 800, q: 8, t: 0.18, v: 0.02, when: i * 0.14 });
  }
  strap(pos?: number[]) {
    if (!this.ok()) return;
    this.n(this.out(pos), { f: 900, f2: 600, q: 4, t: 0.5, v: 0.03, a: 0.15 });
  }
  zap(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos);
    this.n(o, { f: 3500, q: 0.7, t: 0.14, v: 0.22 });
    this.n(o, { f: 800, type: "highpass", t: 0.25, v: 0.12, when: 0.05 });
    this.tn(o, { f: 120, t: 0.2, v: 0.06, type: "square" });
  }
  flickerBuzz(pos?: number[]) {
    if (!this.ok()) return;
    const o = this.out(pos);
    for (let i = 0; i < 4; i++) this.n(o, { f: 2500, q: 1, t: 0.05, v: 0.06, when: i * 0.09 + Math.random() * 0.04 });
    this.tn(o, { f: 100, t: 0.4, v: 0.03, type: "sawtooth" });
  }
  thud() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 120, type: "lowpass", t: 0.9, v: 0.35, a: 0.01 });
    this.tn(this.sfx, { f: 60, f2: 35, t: 1, v: 0.25 });
  }

  // ---------- character ----------
  step(run: boolean) {
    if (!this.ok()) return;
    const v = run ? 0.5 : 0.3;
    const o = this.sfx;
    this.n(o, { f: 220 + Math.random() * 60, type: "lowpass", t: 0.11, v, q: 0.7 });
    this.n(o, { f: 2400 + Math.random() * 600, q: 1, t: 0.04, v: v * 0.25 });
    this.tn(o, { f: 95, f2: 60, t: 0.1, v: v * 0.5 });
  }
  pickup() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 3000, f2: 1500, q: 0.8, t: 0.2, v: 0.12, a: 0.03 });
    this.tn(this.sfx, { f: 520, f2: 780, t: 0.18, v: 0.07, type: "triangle", when: 0.03 });
  }
  drop() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 700, type: "lowpass", t: 0.1, v: 0.3 });
    this.tn(this.sfx, { f: 300, f2: 180, t: 0.1, v: 0.1, when: 0 });
    this.n(this.sfx, { f: 1800, q: 2, t: 0.05, v: 0.08, when: 0.12 });
  }
  paper() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 5000, f2: 3000, q: 0.5, t: 0.25, v: 0.1, a: 0.05 });
  }

  // ---------- interactions ----------
  doorOpen() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 180, f2: 320, q: 3, t: 1.4, v: 0.16, a: 0.2 });
    this.tn(this.sfx, { f: 90, f2: 130, t: 1.3, v: 0.07, type: "sawtooth", a: 0.3 });
    this.n(this.sfx, { f: 150, type: "lowpass", t: 0.5, v: 0.3, when: 1.2 });
  }
  unlock() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 2500, q: 3, t: 0.07, v: 0.25 });
    this.n(this.sfx, { f: 900, q: 4, t: 0.12, v: 0.3, when: 0.18 });
    this.tn(this.sfx, { f: 200, f2: 120, t: 0.3, v: 0.12, when: 0.18, type: "square" });
  }
  locked() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 1200, q: 5, t: 0.06, v: 0.2 });
    this.n(this.sfx, { f: 700, q: 5, t: 0.08, v: 0.2, when: 0.09 });
  }
  wheel() {
    if (!this.ok()) return;
    for (let i = 0; i < 3; i++) this.n(this.sfx, { f: 2200 - i * 300, q: 6, t: 0.03, v: 0.14, when: i * 0.045 });
    this.tn(this.sfx, { f: 180, f2: 140, t: 0.12, v: 0.06, type: "square" });
  }
  button() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 1500, q: 2, t: 0.05, v: 0.25 });
    this.tn(this.sfx, { f: 240, f2: 150, t: 0.1, v: 0.1 });
  }
  screwdriver() {
    if (!this.ok()) return;
    for (let i = 0; i < 8; i++) this.n(this.sfx, { f: 3000 + (i % 2) * 500, q: 5, t: 0.04, v: 0.11, when: i * 0.07 });
    this.n(this.sfx, { f: 400, type: "lowpass", t: 0.6, v: 0.05, a: 0.1 });
  }
  switch() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 1800, q: 3, t: 0.04, v: 0.3 });
    this.tn(this.sfx, { f: 160, f2: 90, t: 0.12, v: 0.15, type: "square", when: 0.03 });
    this.n(this.sfx, { f: 3500, q: 1, t: 0.03, v: 0.1, when: 0.1 });
  }
  powerUp() {
    if (!this.ok()) return;
    this.tn(this.sfx, { f: 60, f2: 220, t: 1.8, v: 0.2, type: "sawtooth", a: 0.8 });
    this.n(this.sfx, { f: 300, f2: 4000, q: 1, t: 1.6, v: 0.1, a: 0.9 });
    this.zap();
  }
  error() {
    if (!this.ok()) return;
    this.tn(this.sfx, { f: 130, t: 0.35, v: 0.14, type: "sawtooth" });
    this.tn(this.sfx, { f: 98, t: 0.4, v: 0.14, type: "sawtooth", when: 0.12 });
  }
  solve() {
    if (!this.ok()) return;
    [392, 494, 587, 784].forEach((f, i) => this.tn(this.sfx, { f, t: 0.8, v: 0.09, type: "triangle", when: i * 0.13, a: 0.02 }));
    this.n(this.sfx, { f: 600, f2: 200, q: 2, t: 0.8, v: 0.12, when: 0.5 });
  }
  flashlight(on: boolean) {
    if (!this.ok()) return;
    this.n(this.sfx, { f: on ? 1800 : 1300, q: 2, t: 0.035, v: 0.18 });
    this.tn(this.sfx, { f: on ? 300 : 220, t: 0.05, v: 0.06, type: "square" });
  }
  ui() {
    if (!this.ok()) return;
    this.n(this.sfx, { f: 2200, q: 2, t: 0.03, v: 0.1 });
  }
  escape() {
    if (!this.ok()) return;
    [196, 294, 392, 587, 784].forEach((f, i) => this.tn(this.music, { f, t: 5, v: 0.1, a: 1.2, when: i * 0.5 }));
    this.n(this.sfx, { f: 400, f2: 3000, q: 0.6, t: 4, v: 0.15, a: 2 });
  }
}
export const audio = new AudioSys();
