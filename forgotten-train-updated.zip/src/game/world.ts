// @ts-nocheck
// Environment dressing built AROUND the untouched train GLB (the GLB only contains the two leather benches).
import * as THREE from "three";
import * as TX from "./textures";

export interface Dims {
  L: number;
  W: number;
  hw: number;
  hl: number;
  CH: number;
  seatInner: number;
  S: number;
  seatTop: number;
}
export const DOOR_W = 1.2;
export const DOOR_H = 2.15;

export function makeMaterials() {
  const wallT = TX.ct(TX.wallCanvas());
  const floorT = TX.ct(TX.floorCanvas());
  const ceilT = TX.ct(TX.ceilCanvas());
  const M: any = {};
  const std = (o: any) => {
    const m = new THREE.MeshStandardMaterial({ envMapIntensity: 0.45, ...o });
    m.fog = false;
    return m;
  };
  M.wall = std({ map: wallT, roughness: 0.82, metalness: 0.45, color: 0xb8c0c4 });
  M.floor = std({ map: floorT, roughness: 0.7, metalness: 0.4 });
  M.ceil = std({ map: ceilT, roughness: 0.9, metalness: 0.2 });
  M.metal = std({ color: 0x2e3234, roughness: 0.55, metalness: 0.85 });
  M.rust = std({ color: 0x5a3a24, roughness: 0.9, metalness: 0.5 });
  M.brass = std({ color: 0xc89a3a, roughness: 0.35, metalness: 0.9 });
  M.dark = std({ color: 0x0f1011, roughness: 0.8, metalness: 0.2 });
  M.leather = std({ color: 0x241a14, roughness: 0.7, metalness: 0.1 });
  M.door = std({ map: wallT, color: 0x8f9ba0, roughness: 0.75, metalness: 0.55 });
  M.grille = std({ map: TX.ct(TX.grilleCanvas()), roughness: 0.7, metalness: 0.6 });
  M.glass = new THREE.MeshStandardMaterial({
    color: 0x9fb0b5,
    transparent: true,
    opacity: 0.16,
    roughness: 0.1,
    metalness: 0.0,
    side: THREE.DoubleSide,
    depthWrite: false,
    map: TX.ct(TX.glassCanvas()),
  });
  M.glass.fog = false;
  M.crack = new THREE.MeshBasicMaterial({ map: TX.ct(TX.crackCanvas()), transparent: true, opacity: 0.7, depthWrite: false, side: THREE.DoubleSide });
  M.crack.fog = false;
  M.rustDecal = new THREE.MeshBasicMaterial({ map: TX.ct(TX.rustDecalCanvas()), transparent: true, depthWrite: false, opacity: 0.8 });
  M.rustDecal.fog = false;
  return M;
}

// box whose UVs are scaled to world size (consistent texel density)
export function tbox(w: number, h: number, d: number, tile = 2) {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv;
  const sizes = [
    [d, h],
    [d, h],
    [w, d],
    [w, d],
    [w, h],
    [w, h],
  ];
  for (let f = 0; f < 6; f++)
    for (let v = 0; v < 4; v++) {
      const i = f * 4 + v;
      uv.setXY(i, (uv.getX(i) * sizes[f][0]) / tile, (uv.getY(i) * sizes[f][1]) / tile);
    }
  return g;
}
function mesh(g: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0, name = "") {
  const o = new THREE.Mesh(g, m);
  o.position.set(x, y, z);
  if (name) o.name = name;
  return o;
}

const cache: any = {};
function cyl(r: number, len: number, seg = 8) {
  const k = `c${r}_${len}_${seg}`;
  if (!cache[k]) cache[k] = new THREE.CylinderGeometry(r, r, len, seg);
  return cache[k];
}

export function buildShell(D: Dims, M: any) {
  const g = new THREE.Group();
  const { W, L, hw, CH } = D;
  g.add(mesh(tbox(W, 0.1, L), M.floor, 0, -0.05, 0));
  g.add(mesh(tbox(W, 0.1, L), M.ceil, 0, CH + 0.05, 0));
  for (const z of [-1.1, 1.1]) g.add(mesh(new THREE.BoxGeometry(W, 0.1, 0.12), M.metal, 0, CH - 0.05, z));
  const WIN = [
    [0.55, 1.85],
    [-1.85, -0.55],
  ];
  const sillH = 1.05,
    winTop = 2.0;
  for (const s of [-1, 1]) {
    const x = s * (hw + 0.05);
    g.add(mesh(tbox(0.1, sillH, L), M.wall, x, sillH / 2, 0));
    g.add(mesh(tbox(0.1, CH - winTop, L), M.wall, x, (winTop + CH) / 2, 0));
    const piers = [
      [-0.55, 0.55],
      [1.85, L / 2],
      [-L / 2, -1.85],
    ];
    for (const [a, b] of piers) g.add(mesh(tbox(0.1, winTop - sillH, b - a), M.wall, x, (sillH + winTop) / 2, (a + b) / 2));
    WIN.forEach(([a, b], wi) => {
      const zc = (a + b) / 2,
        wd = b - a,
        wh = winTop - sillH;
      const fx = s * (hw - 0.005);
      // frame
      g.add(mesh(new THREE.BoxGeometry(0.07, 0.06, wd + 0.1), M.metal, fx, sillH, zc));
      g.add(mesh(new THREE.BoxGeometry(0.07, 0.06, wd + 0.1), M.metal, fx, winTop, zc));
      g.add(mesh(new THREE.BoxGeometry(0.07, wh, 0.06), M.metal, fx, (sillH + winTop) / 2, a));
      g.add(mesh(new THREE.BoxGeometry(0.07, wh, 0.06), M.metal, fx, (sillH + winTop) / 2, b));
      // protective horizontal bars (as in the reference)
      for (let i = 1; i <= 5; i++) {
        const bar = mesh(cyl(0.011, wd, 6), M.metal, s * (hw + 0.02), sillH + (wh * i) / 6, zc);
        bar.rotation.x = Math.PI / 2;
        g.add(bar);
      }
      const gl = mesh(new THREE.PlaneGeometry(wd, wh), M.glass, s * (hw + 0.035), (sillH + winTop) / 2, zc);
      gl.rotation.y = Math.PI / 2;
      gl.renderOrder = 2;
      g.add(gl);
      if ((s === 1 && wi === 1) || (s === -1 && wi === 0)) {
        const cr = mesh(new THREE.PlaneGeometry(wd * 0.9, wh * 0.9), M.crack, s * (hw + 0.03), (sillH + winTop) / 2, zc);
        cr.rotation.y = Math.PI / 2;
        cr.renderOrder = 3;
        g.add(cr);
      }
    });
    // luggage racks (segments leave the pier clear for wall consoles)
    for (const [a, b] of [
      [0.75, L / 2 - 0.05],
      [-L / 2 + 0.05, -0.75],
    ]) {
      const len = b - a,
        zc = (a + b) / 2;
      for (const [dx, dy] of [
        [0.0, 0.0],
        [-0.28 * s, 0.05],
      ]) {
        const r = mesh(cyl(0.016, len, 6), M.metal, s * 1.92 + dx, 2.3 + dy, zc);
        r.rotation.x = Math.PI / 2;
        g.add(r);
      }
      for (let i = 0; i <= 5; i++) {
        const sl = mesh(new THREE.BoxGeometry(0.3, 0.012, 0.02), M.metal, s * 1.78, 2.33, a + (len * i) / 5);
        g.add(sl);
      }
    }
    // wall vents on the header
    const v = mesh(new THREE.PlaneGeometry(0.4, 0.25), M.grille, s * (hw - 0.002), 2.35, 0);
    v.rotation.y = -s * Math.PI / 2;
    g.add(v);
    // rust streaks
    for (const zz of [-1.9, 0.0, 1.9]) {
      const r = mesh(new THREE.PlaneGeometry(0.5, 1.0), M.rustDecal, s * (hw - 0.003), 1.5, zz + 0.3);
      r.rotation.y = -s * Math.PI / 2;
      g.add(r);
    }
  }
  // ceiling vents
  for (const z of [-1.55, 1.55]) {
    const v = mesh(new THREE.PlaneGeometry(0.75, 0.4), M.grille, 0, CH - 0.002, z);
    v.rotation.x = Math.PI / 2;
    g.add(v);
  }
  // hand-strap rails and straps
  for (const s of [-1, 1]) {
    const rail = mesh(cyl(0.015, L - 0.2, 6), M.metal, s * 0.85, 2.5, 0);
    rail.rotation.x = Math.PI / 2;
    g.add(rail);
    for (const z of [-1.5, -0.2, 1.1]) {
      const p = new THREE.Group();
      p.name = "strap";
      p.position.set(s * 0.85, 2.5, z + (s > 0 ? 0.3 : 0));
      p.add(mesh(new THREE.BoxGeometry(0.02, 0.28, 0.006), M.leather, 0, -0.14, 0));
      const ring = mesh(new THREE.TorusGeometry(0.075, 0.011, 6, 14), M.metal, 0, -0.34, 0);
      p.add(ring);
      g.add(p);
    }
  }
  return g;
}

export function buildBulkhead(D: Dims, M: any, z: number, opts: any = {}) {
  const g = new THREE.Group();
  g.position.z = z;
  const { hw, CH } = D;
  const T = 0.12;
  const hwOpen = DOOR_W / 2;
  const side = (x0: number, x1: number) => g.add(mesh(tbox(x1 - x0, CH, T), M.wall, (x0 + x1) / 2, CH / 2, 0));
  {
    side(-hw, -hwOpen);
    side(hwOpen, hw);
    g.add(mesh(tbox(DOOR_W, CH - DOOR_H, T), M.wall, 0, (DOOR_H + CH) / 2, 0));
  }
  // door frame
  for (const sx of [-1, 1]) g.add(mesh(new THREE.BoxGeometry(0.09, DOOR_H, T + 0.06), M.metal, sx * (hwOpen + 0.045), DOOR_H / 2, 0));
  g.add(mesh(new THREE.BoxGeometry(DOOR_W + 0.18, 0.09, T + 0.06), M.metal, 0, DOOR_H + 0.045, 0));
  // door panel (slides into the wall pocket)
  const panel = new THREE.Group();
  const pw = opts.sealed ? DOOR_W - 0.02 : DOOR_W - 0.01;
  panel.add(mesh(tbox(pw, DOOR_H, 0.05), M.door, 0, DOOR_H / 2, 0));
  const win = mesh(new THREE.PlaneGeometry(0.3, 0.42), M.dark, 0, 1.55, 0.027);
  panel.add(win);
  const win2 = win.clone();
  win2.position.z = -0.027;
  win2.rotation.y = Math.PI;
  panel.add(win2);
  const wm = new THREE.MeshBasicMaterial({ color: 0x59656a, transparent: true, opacity: 0.25, depthWrite: false });
  panel.add(mesh(new THREE.PlaneGeometry(0.3, 0.42), wm, 0, 1.55, 0.029));
  for (const zz of [0.03, -0.03]) panel.add(mesh(new THREE.BoxGeometry(0.03, 0.22, 0.03), M.metal, 0.35, 1.0, zz));
  panel.add(mesh(new THREE.BoxGeometry(pw - 0.1, 0.02, 0.06), M.rust, 0, 0.25, 0));
  const lampMat = new THREE.MeshBasicMaterial({ color: 0xff2a1a });
  lampMat.fog = false;
  for (const zz of [0.085, -0.085]) {
    const lamp = mesh(new THREE.SphereGeometry(0.04, 10, 8), lampMat, 0, DOOR_H + 0.2, zz);
    g.add(lamp);
    g.add(mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.03, 10).rotateX(Math.PI / 2), M.metal, 0, DOOR_H + 0.2, zz * 0.9));
  }
  g.add(panel);
  let bolt: THREE.Group | null = null;
  if (opts.exit) {
    // heavy wheel lock + sliding bolt bar on the compartment side
    bolt = new THREE.Group();
    bolt.add(mesh(new THREE.BoxGeometry(1.5, 0.1, 0.06), M.rust, 0, 1.05, -0.1));
    bolt.add(mesh(new THREE.BoxGeometry(0.16, 0.2, 0.09), M.metal, -0.75, 1.05, -0.1));
    bolt.add(mesh(new THREE.BoxGeometry(0.16, 0.2, 0.09), M.metal, 0.75, 1.05, -0.1));
    const wheel = mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 20), M.metal, 0, 1.05, -0.14);
    bolt.add(wheel);
    for (let i = 0; i < 3; i++) {
      const sp = mesh(new THREE.BoxGeometry(0.4, 0.03, 0.03), M.metal, 0, 1.05, -0.14);
      sp.rotation.z = (i * Math.PI) / 3;
      bolt.add(sp);
    }
    g.add(bolt);
  }
  return { group: g, panel, lampMat, bolt, glassMat: wm };
}

export function buildFixture(D: Dims, z0: number) {
  const g = new THREE.Group();
  g.position.set(0, D.CH - 0.1, z0);
  const hous = new THREE.MeshStandardMaterial({ color: 0x1b1c1d, roughness: 0.6, metalness: 0.8 });
  g.add(mesh(new THREE.BoxGeometry(0.2, 0.06, 1.15), hous, 0, 0.03, 0));
  const tubeMat = new THREE.MeshStandardMaterial({ color: 0x202418, emissive: 0xeaf3d8, emissiveIntensity: 1, roughness: 0.4 });
  tubeMat.fog = false;
  const t = mesh(cyl(0.028, 1.0, 8), tubeMat, 0, -0.01, 0);
  t.rotation.x = Math.PI / 2;
  g.add(t);
  const t2 = t.clone();
  t2.position.x = 0.06;
  g.add(t2);
  for (const zz of [-0.53, 0.53]) g.add(mesh(new THREE.BoxGeometry(0.2, 0.04, 0.05), M_RUSTY, 0, -0.01, zz));
  const light = new THREE.PointLight(0xffb673, 9, 8.5, 1.6);
  light.position.set(0, -0.15, 0);
  g.add(light);
  return { group: g, tubeMat, light };
}
const M_RUSTY = new THREE.MeshStandardMaterial({ color: 0x4a3426, roughness: 0.9, metalness: 0.4 });

export function buildDebris(D: Dims, z0: number, seed: number) {
  const g = new THREE.Group();
  let a = seed * 9973 + 7;
  const r = () => {
    a = (a * 16807) % 2147483647;
    return a / 2147483647;
  };
  const paperT = TX.ct(TX.labelCanvas(["~~~~~~", "~~~ ~~~", "~~ ~~~~"], 128, 96, { size: 16 }));
  const pm = new THREE.MeshStandardMaterial({ map: paperT, roughness: 1, side: THREE.DoubleSide });
  const pg = new THREE.PlaneGeometry(0.28, 0.2);
  for (let i = 0; i < 7; i++) {
    const p = new THREE.Mesh(pg, pm);
    p.rotation.set(-Math.PI / 2, 0, r() * 6.28);
    p.position.set((r() - 0.5) * 1.5, 0.004 + i * 0.0006, z0 + (r() - 0.5) * 3.8);
    g.add(p);
  }
  const canM = new THREE.MeshStandardMaterial({ color: 0x6a6f6e, roughness: 0.4, metalness: 0.8 });
  for (let i = 0; i < 3; i++) {
    const c = new THREE.Mesh(cyl(0.032, 0.11, 8), canM);
    c.rotation.set(Math.PI / 2, 0, r() * 6.28);
    c.position.set((r() - 0.5) * 1.5, 0.032, z0 + (r() - 0.5) * 3.6);
    g.add(c);
  }
  return g;
}

export function buildSparkBox(M: any, x: number, y: number, z: number, rotY: number) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  g.add(mesh(new THREE.BoxGeometry(0.26, 0.3, 0.1), M.metal, 0, 0, 0.05));
  const lid = mesh(new THREE.BoxGeometry(0.26, 0.3, 0.02), M.rust, 0.03, -0.04, 0.115);
  lid.rotation.z = 0.25;
  g.add(lid);
  const wm = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.6 });
  for (let i = 0; i < 3; i++) {
    const w = mesh(cyl(0.006, 0.34 + i * 0.05, 4), wm, -0.05 + i * 0.05, -0.25, 0.1);
    w.rotation.z = (i - 1) * 0.12;
    g.add(w);
  }
  return g;
}

// ---------- outside ----------
export function buildOutside(scene: THREE.Scene, D: Dims, count = 240) {
  const g = new THREE.Group();
  const black = new THREE.MeshBasicMaterial({ color: 0x050607 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(260, 260), new THREE.MeshBasicMaterial({ color: 0x15181a }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(0, -0.9, 20);
  g.add(ground);
  const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.16, 0.34, 20, 6), black, count);
  const crown = new THREE.InstancedMesh(new THREE.ConeGeometry(2.2, 9, 6), black, count);
  const m = new THREE.Matrix4();
  let a = 1234567;
  const r = () => {
    a = (a * 16807) % 2147483647;
    return a / 2147483647;
  };
  for (let i = 0; i < count; i++) {
    const s = r() < 0.5 ? -1 : 1;
    const x = s * (4.6 + Math.pow(r(), 1.6) * 50);
    const z = -35 + r() * 100;
    const sc = 0.8 + r() * 0.9;
    m.compose(new THREE.Vector3(x, 9 * sc - 0.9, z), new THREE.Quaternion(), new THREE.Vector3(sc, sc, sc));
    trunk.setMatrixAt(i, m);
    m.compose(new THREE.Vector3(x, 17 * sc, z), new THREE.Quaternion(), new THREE.Vector3(sc * (0.7 + r() * 0.5), sc, sc));
    crown.setMatrixAt(i, m);
  }
  g.add(trunk, crown);
  // drifting fog banks
  const c = TX.mk(128, 128, (gx) => {
    const gr = gx.createRadialGradient(64, 64, 4, 64, 64, 62);
    gr.addColorStop(0, "rgba(190,198,200,0.9)");
    gr.addColorStop(1, "rgba(190,198,200,0)");
    gx.fillStyle = gr;
    gx.fillRect(0, 0, 128, 128);
  });
  const fm = new THREE.MeshBasicMaterial({ map: TX.ct(c), transparent: true, opacity: 0.32, depthWrite: false, color: 0x8d979b });
  fm.fog = false;
  const banks: THREE.Mesh[] = [];
  for (let i = 0; i < 14; i++) {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), fm);
    const s = i % 2 ? 1 : -1;
    p.position.set(s * (3.6 + r() * 5), 1.2 + r() * 2, -25 + r() * 70);
    p.rotation.y = s * -Math.PI / 2 + (r() - 0.5) * 0.3;
    p.userData.v = 0.15 + r() * 0.25;
    banks.push(p);
    g.add(p);
  }
  // pale glow beyond the exit door
  const glowM = new THREE.MeshBasicMaterial({ color: 0xdfe6e4, fog: false });
  const glow = new THREE.Mesh(new THREE.PlaneGeometry(6, 4), glowM);
  glow.position.set(0, 1.3, 4 * D.L + D.L / 2 + 1.2);
  glow.rotation.y = Math.PI;
  g.add(glow);
  scene.add(g);
  return {
    group: g,
    glow,
    update(dt: number) {
      for (const b of banks) {
        b.position.z += b.userData.v * dt;
        if (b.position.z > 50) b.position.z = -30;
      }
    },
  };
}

// ---------- pickable props ----------
function sparkle() {
  const c = TX.mk(32, 32, (g) => {
    const gr = g.createRadialGradient(16, 16, 0, 16, 16, 15);
    gr.addColorStop(0, "rgba(255,240,200,1)");
    gr.addColorStop(1, "rgba(255,200,120,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 32, 32);
  });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: TX.ct(c), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.55, fog: false }));
  sp.scale.setScalar(0.16);
  sp.position.y = 0.09;
  sp.name = "sparkle";
  return sp;
}
export function makeProp(id: string, M: any) {
  const g = new THREE.Group();
  g.name = id;
  if (id === "key") {
    g.add(mesh(new THREE.TorusGeometry(0.035, 0.011, 8, 16).rotateX(Math.PI / 2), M.brass, -0.07, 0.012, 0));
    const sh = mesh(new THREE.BoxGeometry(0.11, 0.012, 0.012), M.brass, 0.01, 0.012, 0);
    g.add(sh);
    g.add(mesh(new THREE.BoxGeometry(0.014, 0.012, 0.03), M.brass, 0.045, 0.012, 0.014));
    g.add(mesh(new THREE.BoxGeometry(0.014, 0.012, 0.022), M.brass, 0.03, 0.012, 0.011));
  } else if (id.startsWith("news")) {
    const k = +id.slice(4) - 1;
    if (!cache.page) cache.page = TX.newspaperPage(false);
    if (!cache.pieces) cache.pieces = [0, 1, 2].map((i) => TX.pieceCanvas(cache.page, i));
    const t = TX.ct(cache.pieces[k]);
    const m = new THREE.MeshStandardMaterial({ map: t, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1, metalness: 0 });
    const p = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.28 * 0.72 * 1.0).rotateX(-Math.PI / 2), m);
    p.position.y = 0.008;
    g.add(p);
    g.rotation.y = 0.6 + k;
  } else if (id === "screwdriver") {
    g.add(mesh(cyl(0.017, 0.1, 10).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xa8231d, roughness: 0.5 }), -0.07, 0.018, 0));
    g.add(mesh(cyl(0.005, 0.12, 8).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xb8bec2, roughness: 0.3, metalness: 0.9 }), 0.04, 0.018, 0));
  } else if (id === "ticket") {
    const t = TX.ct(TX.labelCanvas(["NIGHT EXPRESS", "COACH 1 - SEAT 7", "NOT VALID FOR RETURN"], 256, 128, { size: 20, border: "#6a4a20" }));
    g.add(mesh(new THREE.PlaneGeometry(0.16, 0.08).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: t, roughness: 1, side: THREE.DoubleSide }), 0, 0.006, 0));
    g.rotation.y = 0.4;
  } else if (id === "tag") {
    const t = TX.ct(TX.labelCanvas(["LUGGAGE TAG", "C4: POWER PANEL", "OFF BEFORE WIRES"], 256, 128, { size: 20, border: "#6a4a20", bg: "#b8a37a" }));
    g.add(mesh(new THREE.PlaneGeometry(0.13, 0.065).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: t, roughness: 1, side: THREE.DoubleSide }), 0, 0.006, 0));
    g.rotation.y = -0.5;
  }
  g.add(sparkle());
  return g;
}
export function makeNoteSheet(lines: string[], M: any) {
  const g = new THREE.Group();
  const t = TX.ct(TX.labelCanvas(lines, 256, 192, { size: 17 }));
  g.add(mesh(new THREE.PlaneGeometry(0.22, 0.165).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: t, roughness: 1, side: THREE.DoubleSide }), 0, 0.006, 0));
  g.rotation.y = 0.3;
  g.add(sparkle());
  return g;
}
