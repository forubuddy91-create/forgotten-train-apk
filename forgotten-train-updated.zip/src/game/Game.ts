// @ts-nocheck
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { audio } from "./audio";
import { ui } from "./store";
import * as TX from "./textures";
import { PlayerModel } from "./character";
import { NewsPuzzle, CalcPuzzle, PanelPuzzle, MachinePuzzle, Puzzle } from "./puzzles";
import {
  Dims,
  DOOR_W,
  makeMaterials,
  buildShell,
  buildBulkhead,
  buildFixture,
  buildDebris,
  buildSparkBox,
  buildOutside,
  makeProp,
  makeNoteSheet,
} from "./world";

// Asset sources (the user's two repositories; the train file actually lives in "Assets-"). Local copies are the last fallback.
const TRAIN_URLS = [
  "https://forubuddy91-create.github.io/Assets-/abandoned_rusted_train_car_interior_features_worn_leather-asset_wXLwFCzWVqbEMcJipD3X4KNK.glb",
  "https://forubuddy91-create.github.io/Assets/abandoned_rusted_train_car_interior_features_worn_leather-asset_wXLwFCzWVqbEMcJipD3X4KNK.glb",
  "./models/train.glb",
];
const CHAR_URLS = [
  "https://forubuddy91-create.github.io/Assets-/solid_black_matte_mannequin_figure_female_character_stands-asset_ZKcDa9srsjP9hPBwBkZXzgQ5.glb",
  "https://forubuddy91-create.github.io/Assets/solid_black_matte_mannequin_figure_female_character_stands-asset_ZKcDa9srsjP9hPBwBkZXzgQ5.glb",
  "./models/character.glb",
];
const SC = 4.4; // metres per GLB unit (uniform scale; GLB is normalised to 1 unit)
const WALK = 1.9,
  RUN = 3.7,
  RADIUS = 0.27;
const SAVE_KEY = "forgotten_train_save_v1";
const SEAT_Y = 0.47;

export const ITEM_DEFS: any = {
  key: { name: "Brass Key" },
  news1: { name: "Newspaper Fragment I", readable: true },
  news2: { name: "Newspaper Fragment II", readable: true },
  news3: { name: "Newspaper Fragment III", readable: true },
  screwdriver: { name: "Screwdriver" },
  ticket: {
    name: "Old Ticket",
    readable: true,
    text: "NIGHT EXPRESS\nCOACH 1 · SEAT 7\nNOT VALID FOR RETURN\n\nOn the back, in pencil:\n“Five coaches. Five locks.\nEach one answers to something different.”",
  },
  tag: {
    name: "Luggage Tag",
    readable: true,
    text: "LUGGAGE TAG\n\nC4 — POWER PANEL\nThe wire order is written inside.\nAlways switch OFF before touching wires.",
  },
};

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const ease = (t: number) => t * t * (3 - 2 * t);
function angDiff(a: number, b: number) {
  let d = (a - b) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

function newF(L: number) {
  return {
    seat: false,
    under: false,
    doors: [0, 0, 0, 0, 0],
    items: {
      key: { loc: "world", hidden: true, pos: [1.62, SEAT_Y, 0.9] },
      news1: { loc: "world", hidden: false, pos: [0.4, 0.012, 1.2] },
      ticket: { loc: "world", hidden: false, pos: [-1.6, SEAT_Y, -0.5] },
      news2: { loc: "world", hidden: false, pos: [-1.6, SEAT_Y, L - 0.8] },
      news3: { loc: "world", hidden: true, pos: [0.78, 0.012, L + 1.0] },
      tag: { loc: "world", hidden: false, pos: [1.6, SEAT_Y, 2 * L - 0.9] },
      screwdriver: { loc: "world", hidden: true, pos: [-1.9, 1.5, 2 * L] },
    },
    news: { placed: [false, false, false], order: [2, 0, 1], flip: [0, 1, 0], solved: false },
    calc: { wheels: [0, 0, 0], solved: false },
    panel: { screws: [1, 1, 1, 1], breaker: true, seq: [], done: false },
    machine: { cont: [3, 5, 0, 2, 1], solved: false },
    escaped: false,
  };
}

class Door {
  state = 0; // 0 locked 1 unlocking 2 unlocked 3 opening 4 open
  t = 0;
  slide = 0;
  constructor(public k: number, public z: number, public panel: any, public lampMat: any, public bolt: any, public glassMat: any) {}
}

export class Game {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(58, 16 / 9, 0.05, 120);
  time = 0;
  last = 0;
  D: Dims;
  M: any;
  F: any;
  inv: (string | null)[] = [null, null, null, null, null];
  sel = 0;
  trainGltf: any;
  charGltf: any;
  envTex: any;
  ready = false;
  comps: any[] = [];
  doors: Door[] = [];
  straps: any[] = [];
  glass: any[] = [];
  sparkBoxes: any[] = [];
  props: any = {};
  falling: any[] = [];
  inters: any[] = [];
  puzzles: any = {};
  puzzle: Puzzle | null = null;
  blend = 0;
  pm: PlayerModel;
  px = 0;
  pz = -1.1;
  yaw = 0;
  camYaw = 0;
  camPitch = 0.2;
  camYawS = 0;
  camPitchS = 0.2;
  speed = 0;
  velDir = new THREE.Vector2(0, 1);
  input = { x: 0, y: 0, keys: {} as any };
  cur: any = null;
  curSig = "";
  flashOn = false;
  flashI = 0;
  lights: any = {};
  colliders: number[][] = [];
  timers: any[] = [];
  evTimer = 8;
  swayBoost = 0;
  rattleT = 0;
  rumbleT = 0;
  surgeT = 0;
  escaping = 0;
  hintSig = "";
  hintT = 0;
  lastTarget = new THREE.Vector3();
  camPos = new THREE.Vector3(0, 2, -3);
  camLook = new THREE.Vector3();
  raycaster = new THREE.Raycaster();
  saveT = 0;
  curComp = 0;
  toastId = 0;
  measure: any = {};
  boardMat: any;
  boardTexOn: any;
  dust: any;
  insects: any;
  sparks: any;
  spark = { pos: new Float32Array(40 * 3), vel: new Float32Array(40 * 3), life: new Float32Array(40), n: 0 };
  outside: any;
  groupsByComp: any[] = [];
  puzzleGroup = new THREE.Group();
  interactCool = 0;

  // ---------------------------------------------------------------- setup
  mount(canvas: HTMLCanvasElement) {
    if (this.canvas) return;
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.scene.background = new THREE.Color(0x3d444a);
    this.scene.fog = new THREE.Fog(0x3d444a, 5, 42);
    window.addEventListener("resize", () => this.resize());
    window.addEventListener("keydown", (e) => this.key(e, true));
    window.addEventListener("keyup", (e) => this.key(e, false));
    ui.set({ hasSave: !!localStorage.getItem(SAVE_KEY) });
    this.load().catch((e) => {
      console.error(e);
      ui.set({ loadErr: String(e && e.message ? e.message : e) });
    });
    this.last = performance.now();
    this.renderer.setAnimationLoop((now: number) => {
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      this.update(dt);
    });
    this.applySettings();
    this.resize();
  }
  async tryLoad(urls: string[], onp: (f: number) => void) {
    const loader = new GLTFLoader();
    loader.setCrossOrigin("anonymous");
    let err;
    for (const u of urls) {
      try {
        return await loader.loadAsync(u, (e: ProgressEvent) => e.total && onp(e.loaded / e.total));
      } catch (e) {
        err = e;
        console.warn("GLB load failed, trying next source:", u, e);
      }
    }
    throw new Error("Could not load model: " + (err && err.message));
  }
  async load() {
    let a = 0,
      b = 0;
    const rep = () => ui.set({ loadPct: Math.round(((a + b) / 2) * 100) });
    [this.trainGltf, this.charGltf] = await Promise.all([
      this.tryLoad(TRAIN_URLS, (f) => ((a = f), rep())),
      this.tryLoad(CHAR_URLS, (f) => ((b = f), rep())),
    ]);
    this.initWorld();
    this.ready = true;
    this.newGameState();
    ui.set({ assetsReady: true, screen: "menu", loadPct: 100 });
  }
  applySettings() {
    const s = ui.get().settings;
    audio.setVolumes(s.master, s.sfx, s.music);
    if (!this.renderer) return;
    const dpr = window.devicePixelRatio || 1;
    this.pr = s.quality === "low" ? Math.min(dpr, 0.6) : s.quality === "medium" ? Math.min(dpr, 0.85) : Math.min(dpr, 1.3);
    this.renderer.setPixelRatio(this.pr);
    this.renderer.shadowMap.enabled = s.quality === "high";
    if (this.lights.flash) {
      this.lights.flash.castShadow = s.quality === "high";
      this.lights.flash.shadow.mapSize.set(1024, 1024);
      this.lights.flash.shadow.bias = -0.0008;
    }
    this.resize();
  }
  pr = 1;
  resize() {
    if (!this.renderer) return;
    const w = window.innerWidth,
      h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.fov = w / h < 1.4 ? 66 : 58;
    this.camera.updateProjectionMatrix();
  }
  key(e: KeyboardEvent, down: boolean) {
    const k = e.key.toLowerCase();
    this.input.keys[k] = down;
    if (down && !e.repeat) {
      if (k === "e" || k === "enter") this.interact();
      if (k === "f") this.toggleFlashlight();
      if (k >= "1" && k <= "5") this.selectSlot(+k - 1);
      if (k === "q") this.dropSelected();
      if (k === "escape") {
        if (this.puzzle) this.exitPuzzle();
        else if (ui.get().note) this.closeNote();
        else if (ui.get().screen === "playing") this.pause();
        else if (ui.get().screen === "paused") this.resume();
      }
    }
  }

  initWorld() {
    const tg = this.trainGltf.scene;
    let tm: THREE.Mesh | null = null;
    tg.traverse((o: any) => {
      if (o.isMesh && !tm) tm = o;
    });
    const geo = tm!.geometry;
    geo.computeBoundingBox();
    const bb = geo.boundingBox!;
    const size = new THREE.Vector3();
    bb.getSize(size);
    // inspect real geometry: nearest vertex to the centre line = bench inner edge
    const pos = geo.attributes.position;
    let minAbsX = 9;
    for (let i = 0; i < pos.count; i++) {
      const ax = Math.abs(pos.getX(i));
      if (ax < minAbsX) minAbsX = ax;
    }
    const L = size.z * SC,
      W = size.x * SC;
    this.D = { L, W, hw: W / 2, hl: L / 2, CH: 2.7, seatInner: minAbsX * SC, S: SC, seatTop: SEAT_Y };
    this.measure = { bbox: bb.min.toArray().concat(bb.max.toArray()), size: size.toArray(), scale: SC, length: L, width: W, height: size.y * SC, seatInner: this.D.seatInner };
    console.info("[train GLB] measured:", this.measure);
    const D = this.D;
    const M = (this.M = makeMaterials());
    // environment reflections (the GLB materials are largely metallic)
    const pm = new THREE.PMREMGenerator(this.renderer);
    this.envTex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    pm.dispose();
    const trainMat = tm!.material as THREE.MeshStandardMaterial;
    trainMat.envMap = this.envTex;
    trainMat.envMapIntensity = 0.75;
    trainMat.fog = false;
    [M.wall, M.floor, M.ceil, M.metal, M.rust, M.brass, M.dark, M.leather, M.door, M.grille, M.glass].forEach((m: any) => (m.envMap = this.envTex));
    // ---- lights
    this.scene.add(new THREE.HemisphereLight(0x7d8f99, 0x1c1814, 0.6));
    const flash = new THREE.SpotLight(0xfff0d8, 0, 17, 0.4, 0.55, 1.4);
    flash.target.position.set(0, 1, 3);
    this.scene.add(flash, flash.target);
    const fill = new THREE.PointLight(0xa8bcd8, 1.6, 4.5, 2);
    this.scene.add(fill);
    this.lights = { flash, fill };
    // ---- five instances of the SAME geometry + material (one GLB load)
    const shell = buildShell(D, M);
    const floorOff = -bb.min.y * SC;
    for (let i = 0; i < 5; i++) {
      const z0 = i * L;
      const grp = new THREE.Group();
      const t = new THREE.Mesh(geo, trainMat);
      t.scale.setScalar(SC);
      t.position.set(0, floorOff, 0);
      t.name = "trainInstance" + i;
      grp.add(t);
      const sh = shell.clone();
      grp.add(sh);
      const fx = buildFixture(D, 0);
      grp.add(fx.group);
      // lights live in the scene root so toggling compartment visibility never changes the light count (no shader recompiles)
      fx.group.remove(fx.light);
      fx.light.position.set(0, D.CH - 0.3, z0);
      this.scene.add(fx.light);
      grp.add(buildDebris(D, 0, i + 1));
      for (const s of [-1, 1]) grp.add(buildSparkBox(M, s * (D.hw - 0.0), 1.55, D.hl - 0.2, -s * Math.PI / 2));
      grp.position.z = z0;
      this.scene.add(grp);
      this.groupsByComp.push(grp);
      this.comps.push({ grp, fx, mult: 1, flick: 0, base: [1, 0.8, 0.9, 1, 1][i], z0 });
      sh.traverse((o: any) => {
        if (o.name === "strap") this.straps.push(o);
        if (o.isMesh && o.material === M.glass) {
          o.userData.bx = o.position.x;
          this.glass.push(o);
        }
      });
      this.sparkBoxes.push({ comp: i, pos: new THREE.Vector3(D.hw - 0.1, 1.5, z0 + D.hl - 0.2) });
    }
    // bulkheads / doors (k = door between compartment k and k+1, k=4 is the exit)
    const back = buildBulkhead(D, M, -D.hl, { sealed: true });
    this.scene.add(back.group);
    back.lampMat.color.setHex(0x551008);
    for (let k = 0; k < 5; k++) {
      const z = k * L + D.hl;
      const b = buildBulkhead(D, M, z, { exit: k === 4 });
      this.scene.add(b.group);
      this.doors.push(new Door(k, z, b.panel, b.lampMat, b.bolt, b.glassMat));
    }
    // outside forest + fog
    this.outside = buildOutside(this.scene, D);
    // dust, insects, sparks
    const dotTex = TX.ct(TX.mk(32, 32, (g) => {
      const gr = g.createRadialGradient(16, 16, 0, 16, 16, 15);
      gr.addColorStop(0, "rgba(255,255,255,1)");
      gr.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = gr;
      g.fillRect(0, 0, 32, 32);
    }));
    const mkPts = (n: number, size: number, color: number, op: number, blend?: any) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(n * 3), 3));
      const p = new THREE.Points(g, new THREE.PointsMaterial({ size, color, map: dotTex, transparent: true, opacity: op, depthWrite: false, sizeAttenuation: true, fog: false, blending: blend || THREE.NormalBlending }));
      p.frustumCulled = false;
      this.scene.add(p);
      return p;
    };
    this.dust = mkPts(160, 0.028, 0xd9d0c0, 0.35);
    const dp = this.dust.geometry.attributes.position.array;
    for (let i = 0; i < dp.length; i += 3) {
      dp[i] = (Math.random() - 0.5) * 6;
      dp[i + 1] = Math.random() * 2.6;
      dp[i + 2] = (Math.random() - 0.5) * 6;
    }
    this.insects = mkPts(9, 0.035, 0x050505, 0.95);
    this.sparks = mkPts(40, 0.06, 0xffd890, 1, THREE.AdditiveBlending);
    // player
    this.pm = new PlayerModel(this.charGltf);
    this.pm.mesh.material.envMap = this.envTex;
    this.scene.add(this.pm.root);
    this.scene.add(this.puzzleGroup);
    // colliders
    const hw = D.hw;
    for (let i = 0; i < 5; i++) {
      const z0 = i * L;
      this.colliders.push([-hw, -D.seatInner, z0 - D.hl, z0 + D.hl]);
      this.colliders.push([D.seatInner, hw, z0 - D.hl, z0 + D.hl]);
    }
    const jw = DOOR_W / 2;
    this.colliders.push([-hw, hw, -D.hl - 0.1, -D.hl + 0.07]);
    for (let k = 0; k < 5; k++) {
      const z = k * L + D.hl;
      this.colliders.push([-hw, -jw, z - 0.08, z + 0.08]);
      this.colliders.push([jw, hw, z - 0.08, z + 0.08]);
    }
    const ez = 4 * L + D.hl;
    this.colliders.push([-4, -jw - 0.06, ez, ez + 3.2]);
    this.colliders.push([jw + 0.06, 4, ez, ez + 3.2]);
    this.colliders.push([-4, 4, ez + 3.2, ez + 3.6]);
    // route board (C4)
    const bg = new THREE.Group();
    bg.position.set(-hw, 0, 3 * L);
    bg.rotation.y = Math.PI / 2;
    bg.add(new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.62, 0.06), M.metal)).position.set(0, 1.85, 0.03);
    this.boardTexOff = TX.ct(TX.labelCanvas([""], 256, 128, { bg: "#08090a" }));
    this.boardCanvasOn = TX.mk(512, 256, (g, w, h) => {
      g.fillStyle = "#0b0d08";
      g.fillRect(0, 0, w, h);
      g.fillStyle = "#ffb840";
      g.textAlign = "center";
      g.font = "bold 30px Courier New, monospace";
      g.fillText("ROUTE SIGNS 4 · 5", w / 2, 44);
      TX.drawSymbol(g, "diamond", 170, 128, 44, "#ffb840", 10);
      TX.drawSymbol(g, "circle", 342, 128, 44, "#ffb840", 10);
      g.font = "bold 20px Courier New, monospace";
      g.fillText("SIGNS 1-3 : SEE THE EVENING PAPER", w / 2, 208);
      g.fillText("FINAL SIGNAL — COACH 5", w / 2, 238);
    });
    this.boardTexOn = TX.ct(this.boardCanvasOn);
    this.boardMat = new THREE.MeshBasicMaterial({ map: this.boardTexOff });
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.52), this.boardMat);
    scr.position.set(0, 1.85, 0.065);
    bg.add(scr);
    this.scene.add(bg);
    // props
    for (const id of Object.keys(ITEM_DEFS)) {
      const p = makeProp(id, M);
      this.props[id] = p;
      this.scene.add(p);
    }
    this.props.note1 = makeNoteSheet(["FOUND THIS TRAIN", "ABANDONED. IF YOU READ", "THIS: SEARCH THE SEATS.", "PAGES OF THE EVENING", "PAPER WERE TORN UP", "AND SCATTERED.", "- THE CONDUCTOR"], M);
    this.props.note1.position.set(-1.6, SEAT_Y, -0.95);
    this.scene.add(this.props.note1);
    this.buildInteractables();
    this.scene.updateMatrixWorld(true);
  }

  // ---------------------------------------------------------------- state
  newGameState() {
    this.F = newF(this.D.L);
    this.inv = [null, null, null, null, null];
    this.sel = 0;
    this.px = 0;
    this.pz = -1.1;
    this.yaw = 0;
    this.camYaw = this.camYawS = 0;
    this.camPitch = this.camPitchS = 0.2;
    this.speed = 0;
    this.escaping = 0;
    this.flashOn = false;
    this.applyState();
  }
  applyState() {
    // puzzles
    this.puzzleGroup.clear();
    this.puzzles = {};
    this.puzzle = null;
    this.blend = 0;
    const D = this.D,
      L = D.L,
      F = this.F;
    const ctx: any = {
      F,
      audio,
      M: this.M,
      toast: (t: string, k?: string) => this.toast(t, k || "info"),
      hasSelected: (id: string) => this.inv[this.sel] === id,
      hasItem: (id: string) => this.inv.includes(id),
      consumeItem: (id: string) => this.consumeItem(id),
      save: () => this.save(),
      onSolved: (n: string) => this.onSolved(n),
      surge: () => (this.surgeT = 1.6),
      spark: (p: THREE.Vector3) => this.emitSparks(p, 22),
    };
    const place = (p: Puzzle, comp: number, side: number) => {
      p.group.position.set(side * D.hw, 0, comp * L);
      p.group.rotation.y = side > 0 ? -Math.PI / 2 : Math.PI / 2;
      this.puzzleGroup.add(p.group);
    };
    this.puzzles.news = new NewsPuzzle(ctx);
    place(this.puzzles.news, 1, 1);
    this.puzzles.calc = new CalcPuzzle(ctx);
    place(this.puzzles.calc, 2, -1);
    this.puzzles.panel = new PanelPuzzle(ctx);
    place(this.puzzles.panel, 3, 1);
    this.puzzles.machine = new MachinePuzzle(ctx);
    place(this.puzzles.machine, 4, -1);
    this.puzzleGroup.updateMatrixWorld(true);
    // screwdriver reveal position (calc drawer)
    F.items.screwdriver.pos = this.puzzles.calc.drawerItemWorld().toArray();
    // doors
    this.doors.forEach((d, k) => {
      d.state = F.doors[k];
      d.t = 0;
      d.slide = d.state === 4 ? 1.18 : 0;
      this.setDoorVisual(d);
    });
    // props
    for (const id of Object.keys(ITEM_DEFS)) {
      const it = F.items[id];
      const p = this.props[id];
      p.visible = it.loc === "world" && !it.hidden;
      p.position.set(it.pos[0], it.pos[1], it.pos[2]);
    }
    this.falling = [];
    this.boardMat.map = F.panel.done ? this.boardTexOn : this.boardTexOff;
    this.boardMat.needsUpdate = true;
    this.syncHotbar();
    ui.set({ flashlight: this.flashOn, puzzle: null, note: null, prompt: null, fade: 0 });
    this.timers = [];
    this.evTimer = 9;
    this.pm.root.position.set(this.px, 0, this.pz);
    this.pm.root.rotation.y = this.yaw;
    this.pm.action = null;
  }
  serialize() {
    return JSON.stringify({ v: 1, F: this.F, inv: this.inv, sel: this.sel, px: this.px, pz: this.pz, yaw: this.yaw, camYaw: this.camYaw, flash: this.flashOn });
  }
  save() {
    if (this.escaping || this.F.escaped) return;
    try {
      localStorage.setItem(SAVE_KEY, this.serialize());
      ui.set({ hasSave: true });
    } catch {
      /* ignore */
    }
  }
  loadSave(): boolean {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const s = JSON.parse(raw);
      if (s.v !== 1) return false;
      this.F = s.F;
      this.inv = s.inv;
      this.sel = s.sel || 0;
      this.px = s.px;
      this.pz = s.pz;
      this.yaw = s.yaw;
      this.camYaw = this.camYawS = s.camYaw || 0;
      this.flashOn = !!s.flash;
      this.speed = 0;
      this.applyState();
      return true;
    } catch (e) {
      console.warn("bad save", e);
      return false;
    }
  }

  // ---------------------------------------------------------------- UI-facing API
  startNew() {
    audio.init();
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
    this.newGameState();
    ui.set({ screen: "playing", hasSave: false });
    this.tryOrientation();
    this.toast("Find a way out of this train.", "objective");
  }
  continueGame() {
    audio.init();
    if (!this.loadSave()) return this.startNew();
    ui.set({ screen: "playing" });
    this.tryOrientation();
    this.toast("Game restored.", "info");
  }
  tryOrientation() {
    try {
      const el: any = document.documentElement;
      if (el.requestFullscreen && !document.fullscreenElement) el.requestFullscreen().catch(() => {});
      (screen as any).orientation?.lock?.("landscape").catch(() => {});
    } catch {
      /* ignore */
    }
  }
  pause() {
    if (ui.get().screen !== "playing") return;
    this.save();
    audio.suspend();
    ui.set({ screen: "paused" });
  }
  resume() {
    audio.resume();
    ui.set({ screen: "playing" });
  }
  restart() {
    this.startNew();
  }
  toMenu() {
    if (!this.F.escaped) this.save();
    audio.resume();
    this.newGameStateKeepSave();
    ui.set({ screen: "menu" });
  }
  newGameStateKeepSave() {
    this.newGameState();
  }
  toggleFlashlight() {
    if (ui.get().screen !== "playing") return;
    this.flashOn = !this.flashOn;
    audio.flashlight(this.flashOn);
    ui.set({ flashlight: this.flashOn });
  }
  joystick(x: number, y: number) {
    this.input.x = x;
    this.input.y = y;
  }
  look(dx: number, dy: number) {
    const s = ui.get().settings.sens;
    this.camYaw -= dx * 0.0052 * s;
    this.camPitch = clamp(this.camPitch + dy * 0.0042 * s, -0.12, 0.95);
  }
  selectSlot(i: number) {
    if (ui.get().screen !== "playing") return;
    if (i === this.sel && this.inv[i] && ITEM_DEFS[this.inv[i]!].readable) {
      this.readItem(this.inv[i]!);
      return;
    }
    this.sel = i;
    audio.ui();
    this.syncHotbar();
  }
  syncHotbar() {
    ui.set({ hotbar: [...this.inv], selected: this.sel });
  }
  readItem(id: string) {
    const d = ITEM_DEFS[id];
    audio.paper();
    if (id.startsWith("news")) {
      const k = +id.slice(4) - 1;
      const page = TX.newspaperPage(false);
      ui.set({ note: { title: d.name, body: "A torn fragment of the evening paper. The edges are jagged — the other pieces must be somewhere on this train. Compare them on the evidence board.", img: TX.pieceCanvas(page, k).toDataURL() } });
    } else ui.set({ note: { title: d.name, body: d.text } });
  }
  closeNote() {
    ui.set({ note: null });
  }
  toast(text: string, kind = "info") {
    ui.set({ toast: { id: ++this.toastId, text, kind } });
  }
  addItem(id: string) {
    const slot = this.inv.indexOf(null);
    if (slot < 0) {
      this.toast("Hotbar full — drop something first.");
      audio.error();
      return false;
    }
    this.inv[slot] = id;
    this.F.items[id].loc = "inv";
    this.props[id].visible = false;
    audio.pickup();
    this.syncHotbar();
    this.toast("Picked up: " + ITEM_DEFS[id].name, "item");
    this.save();
    return true;
  }
  consumeItem(id: string) {
    const i = this.inv.indexOf(id);
    if (i >= 0) this.inv[i] = null;
    this.F.items[id].loc = "used";
    this.syncHotbar();
  }
  dropSelected() {
    if (ui.get().screen !== "playing" || this.puzzle) return;
    const id = this.inv[this.sel];
    if (!id) return;
    this.inv[this.sel] = null;
    const x = clamp(this.px + Math.sin(this.yaw) * 0.7, -0.85, 0.85);
    const z = this.pz + Math.cos(this.yaw) * 0.7;
    const it = this.F.items[id];
    it.loc = "world";
    it.hidden = false;
    it.pos = [x, 1.0, z];
    const p = this.props[id];
    p.visible = true;
    p.position.set(x, 1.0, z);
    this.falling.push({ id, vy: 0 });
    this.pm.play("drop", 0.6);
    this.syncHotbar();
    this.save();
  }
  interact() {
    if (ui.get().screen !== "playing" || this.puzzle || this.interactCool > 0) return;
    const g = this.cur && this.cur.g;
    if (g && g.actionable && g.act) {
      this.interactCool = 0.3;
      g.act();
    }
  }
  puzzleTap(cx: number, cy: number) {
    if (!this.puzzle || this.blend < 0.8) return;
    const r = this.canvas.getBoundingClientRect();
    const v = new THREE.Vector2(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    this.camera.updateMatrixWorld(true);
    this.raycaster.setFromCamera(v, this.camera);
    const objs = this.puzzle.pick.filter((m) => m.visible);
    const hits = this.raycaster.intersectObjects(objs, false);
    if (hits.length && hits[0].object.userData.tap) hits[0].object.userData.tap();
  }
  enterPuzzle(p: Puzzle, comp: number) {
    this.puzzle = p;
    p.enter();
    this.hintSig = "";
    const g = p.group.position;
    this.yaw = g.x > 0 ? Math.PI / 2 : -Math.PI / 2;
    this.pm.play("operate", 1, true);
    ui.set({ puzzle: { title: p.title, hint: p.hint() }, prompt: null });
    audio.ui();
  }
  exitPuzzle() {
    if (!this.puzzle) return;
    this.puzzle.exit();
    this.puzzle = null;
    this.pm.stop();
    ui.set({ puzzle: null });
    audio.ui();
    this.save();
  }
  after(sec: number, fn: () => void) {
    this.timers.push({ t: sec, fn });
  }

  // ---------------------------------------------------------------- progression
  unlockDoor(k: number) {
    const d = this.doors[k];
    if (d.state !== 0) return;
    d.state = 1;
    d.t = 0;
    audio.unlock();
    this.save();
  }
  onSolved(name: string) {
    const F = this.F;
    if (name === "news") this.after(1.6, () => (this.unlockDoor(1), this.toast("A door lock clunks somewhere ahead.", "objective")));
    if (name === "calc") {
      this.after(1.6, () => {
        this.unlockDoor(2);
        F.items.screwdriver.hidden = false;
        F.items.screwdriver.loc = "world";
        const p = this.puzzles.calc.drawerItemWorld();
        F.items.screwdriver.pos = p.toArray();
        this.props.screwdriver.position.copy(p);
        this.props.screwdriver.visible = true;
        this.toast("A drawer slid open. A screwdriver lies inside.", "objective");
      });
    }
    if (name === "panel") {
      this.after(1.4, () => this.unlockDoor(3));
      this.boardMat.map = this.boardTexOn;
      this.boardMat.needsUpdate = true;
    }
    if (name === "machine") {
      this.after(1.6, () => this.unlockDoor(4));
    }
    this.save();
  }
  setDoorVisual(d: Door) {
    d.panel.position.x = d.slide;
    const c = d.state === 0 ? 0xff2a1a : d.state === 1 ? 0xffb020 : 0x2cff60;
    d.lampMat.color.setHex(c);
    if (d.bolt) d.bolt.position.x = d.state >= 1 ? 0.7 : 0;
  }
  updateDoors(dt: number) {
    for (const d of this.doors) {
      if (d.state === 1) {
        d.t += dt;
        d.lampMat.color.setHex(Math.floor(d.t * 8) % 2 ? 0xffb020 : 0x553a08);
        if (d.bolt) d.bolt.position.x = ease(clamp(d.t / 1.2, 0, 1)) * 0.7;
        if (d.t >= 1.4) {
          d.state = 2;
          this.F.doors[d.k] = 2;
          this.setDoorVisual(d);
          audio.unlock();
          this.save();
        }
      } else if (d.state === 3) {
        d.t += dt / 1.7;
        d.slide = ease(clamp(d.t, 0, 1)) * 1.18;
        d.panel.position.x = d.slide;
        if (d.t >= 1) {
          d.state = 4;
          this.F.doors[d.k] = 4;
          this.setDoorVisual(d);
          this.save();
        }
      }
    }
  }
  doorBlocking(d: Door) {
    return d.state < 4 ? [-DOOR_W / 2 + d.slide, DOOR_W / 2, d.z - 0.1, d.z + 0.1] : null;
  }

  // ---------------------------------------------------------------- interactables
  buildInteractables() {
    const D = this.D,
      L = D.L,
      F = () => this.F;
    const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
    const I = this.inters;
    // collectibles
    for (const id of Object.keys(ITEM_DEFS)) {
      I.push({
        pos: this.props[id].position,
        range: 1.55,
        fov: 1.1,
        get: () => {
          const it = F().items[id];
          if (it.loc !== "world" || it.hidden || this.falling.some((f) => f.id === id)) return null;
          return {
            text: "Pick up",
            sub: ITEM_DEFS[id].name,
            actionable: true,
            act: () => {
              if (this.addItem(id)) this.pm.play("pickup", 0.75);
            },
          };
        },
      });
    }
    const info = (pos: any, text: string, sub: string, range = 1.6) =>
      I.push({
        pos,
        range,
        fov: 1.1,
        get: () => ({
          text: "Investigate",
          sub,
          actionable: true,
          act: () => {
            this.pm.play("interact", 0.8);
            audio.paper();
            this.toast(text, "info");
          },
        }),
      });
    // C1
    I.push({
      pos: this.props.note1.position,
      range: 1.6,
      fov: 1.1,
      get: () => ({
        text: "Read",
        sub: "Handwritten note",
        actionable: true,
        act: () => {
          this.pm.play("interact", 0.8);
          audio.paper();
          ui.set({ note: { title: "Handwritten note", body: "FOUND THIS TRAIN ABANDONED.\n\nIf you are reading this: search the seats.\nThe pages of the evening paper were torn up and scattered through the train.\n\nDo not trust the lights.\n\n— The Conductor" } });
        },
      }),
    });
    I.push({
      pos: V(1.6, SEAT_Y, 0.9),
      range: 1.5,
      fov: 1.0,
      get: () =>
        F().seat
          ? null
          : {
              text: "Search",
              sub: "Torn seat cushion",
              actionable: true,
              act: () => {
                F().seat = true;
                F().items.key.hidden = false;
                this.props.key.visible = true;
                this.pm.play("interact", 0.9);
                audio.paper();
                this.toast("Something hard is wedged inside the torn leather…", "info");
                this.save();
              },
            },
    });
    info(V(-2.0, 1.5, -1.2), "Scratched into the window frame: “IT NEVER STOPS AT FIVE.”", "Scratched frame", 1.9);
    // C2
    I.push({
      pos: V(1.6, 0.25, L + 1.0),
      range: 1.5,
      fov: 1.0,
      get: () =>
        F().under
          ? null
          : {
              text: "Look under",
              sub: "Dark gap beneath the bench",
              actionable: true,
              act: () => {
                F().under = true;
                F().items.news3.hidden = false;
                this.props.news3.visible = true;
                this.pm.play("pickup", 0.8);
                audio.paper();
                this.toast("A page has slid out from under the bench.", "info");
                this.save();
              },
            },
    });
    info(V(1.9, 1.5, L + 1.2), "A cracked window. The fog presses against the glass like a hand.", "Cracked window", 2.1);
    // C3
    info(V(1.6, 0.5, 2 * L + 0.9), "The vent rattles faintly. Something dripped here long ago.", "Rusted vent", 1.7);
    // C4
    info(V(1.6, 0.5, 3 * L - 1.0), "A cold, rusted lantern. The wick has not burned in years.", "Old lantern", 1.7);
    // C5
    info(V(-1.6, 0.5, 4 * L + 1.1), "Long scratches tear across the leather. Someone tried to get out.", "Scratched seats", 1.7);
    // route board
    I.push({
      pos: V(-D.hw, 1.8, 3 * L),
      range: 2.5,
      fov: 1.3,
      get: () => ({
        text: "Read",
        sub: "Route board",
        actionable: true,
        act: () => {
          this.pm.play("interact", 0.8);
          if (!F().panel.done) {
            audio.locked();
            this.toast("The display is dead. There is no power.");
          } else {
            audio.paper();
            ui.set({ note: { title: "Route board", body: "The restored display shows the last two route signs: Diamond, then Circle. The first three are in the evening paper.", img: this.boardCanvasOn.toDataURL() } });
          }
        },
      }),
    });
    // puzzles
    const pz = (key: string, comp: number, side: number, text: (() => any)) =>
      I.push({
        pos: V(side * D.hw, 1.7, comp * L),
        range: 2.7,
        fov: 1.25,
        get: () => {
          const g = text();
          if (!g) return null;
          if (g.actionable && !g.act) g.act = () => this.openPuzzle(key, comp);
          return g;
        },
      });
    pz("news", 1, 1, () => ({ text: F().news.solved ? "Read" : "Examine", sub: "Evidence board", actionable: true }));
    pz("calc", 2, -1, () => ({ text: "Operate", sub: "Conductor's Test", actionable: true }));
    pz("machine", 4, -1, () => ({ text: "Examine", sub: "Signal Lock mechanism", actionable: true }));
    pz("panel", 3, 1, () => {
      const P = F().panel;
      const off = P.screws.every((s: number) => !s);
      if (off) return { text: P.done ? "Inspect" : "Repair", sub: "Maintenance panel", actionable: true };
      if (this.inv[this.sel] === "screwdriver") return { text: "Use Screwdriver", sub: "Maintenance panel", actionable: true };
      return { text: "Maintenance panel", sub: "Screwed shut — you need a tool", actionable: false };
    });
    // doors
    const hints = [
      "Bolted — a key would open it",
      "Locked — the evidence board holds the answer",
      "Locked — the Conductor's Test controls this door",
      "Locked — no power. Find the maintenance panel",
      "Exit sealed — the Signal Lock holds it shut",
    ];
    for (const d of this.doors) {
      I.push({
        pos: V(0, 1.1, d.z),
        range: 1.7,
        fov: 1.7,
        get: () => {
          if (d.state === 0) {
            if (d.k === 0 && this.inv[this.sel] === "key")
              return {
                text: "Use Brass Key",
                sub: "Locked door",
                actionable: true,
                act: () => {
                  this.pm.play("interact", 0.9);
                  this.consumeItem("key");
                  this.toast("The key turns. The lock clicks open.", "objective");
                  this.unlockDoor(0);
                },
              };
            const extra = d.k === 0 && this.inv.includes("key") ? "Select the Brass Key in your hotbar" : hints[d.k];
            return { text: "Locked", sub: extra, actionable: false };
          }
          if (d.state === 2)
            return {
              text: "Open door",
              sub: d.k === 4 ? "The exit" : "",
              actionable: true,
              act: () => {
                d.state = 3;
                d.t = 0;
                this.pm.play("interact", 0.9);
                audio.doorOpen();
              },
            };
          return null;
        },
      });
    }
  }
  openPuzzle(key: string, comp: number) {
    this.enterPuzzle(this.puzzles[key], comp);
  }

  // ---------------------------------------------------------------- per-frame
  collide(x: number, z: number) {
    const r = RADIUS;
    const boxes = this.colliders.slice();
    for (const d of this.doors) {
      const b = this.doorBlocking(d);
      if (b) boxes.push(b);
    }
    for (let pass = 0; pass < 3; pass++)
      for (const b of boxes) {
        if (Math.abs(b[2] + b[3] - 2 * z) > b[3] - b[2] + 2 * r + 0.1 && false) continue;
        const cx = clamp(x, b[0], b[1]),
          cz = clamp(z, b[2], b[3]);
        let dx = x - cx,
          dz = z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 < r * r) {
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            x = cx + (dx / d) * r;
            z = cz + (dz / d) * r;
          } else {
            const l = x - b[0] + r,
              rr = b[1] - x + r,
              t = z - b[2] + r,
              bt = b[3] - z + r;
            const m = Math.min(l, rr, t, bt);
            if (m === l) x = b[0] - r;
            else if (m === rr) x = b[1] + r;
            else if (m === t) z = b[2] - r;
            else z = b[3] + r;
          }
        }
      }
    return [x, z];
  }

  updatePlayer(dt: number) {
    const k = this.input.keys;
    const busy = !!this.puzzle || this.blend > 0.02 || !!ui.get().note;
    let mx = 0,
      my = 0,
      run = false;
    if (!busy && !this.escaping) {
      mx = this.input.x + ((k["d"] || k["arrowright"] ? 1 : 0) - (k["a"] || k["arrowleft"] ? 1 : 0));
      my = this.input.y + ((k["w"] || k["arrowup"] ? 1 : 0) - (k["s"] || k["arrowdown"] ? 1 : 0));
      const m = Math.hypot(mx, my);
      if (m > 1) {
        mx /= m;
        my /= m;
      }
      run = !!k["shift"] || Math.hypot(mx, my) > 0.85;
    }
    let mag = Math.hypot(mx, my);
    let dirx = 0,
      dirz = 0;
    if (this.escaping) {
      mag = 0.5;
      dirz = 1;
    } else if (mag > 0.05) {
      const sy = Math.sin(this.camYawS),
        cy = Math.cos(this.camYawS);
      dirx = sy * my - cy * mx;
      dirz = cy * my + sy * mx;
      const l = Math.hypot(dirx, dirz) || 1;
      dirx /= l;
      dirz /= l;
    }
    if (mag > 0.05) {
      this.velDir.set(dirx, dirz);
      const ty = Math.atan2(dirx, dirz);
      this.yaw += angDiff(ty, this.yaw) * (1 - Math.exp(-dt * 13));
    } else if (this.puzzle) {
      // face the console
    }
    const target = mag > 0.05 ? (run ? RUN : WALK * clamp(mag / 0.6, 0.45, 1)) : 0;
    const acc = target > this.speed ? 9 : 13;
    this.speed += clamp(target - this.speed, -acc * dt, acc * dt);
    if (this.speed < 0.01) this.speed = 0;
    const ox = this.px,
      oz = this.pz;
    let nx = this.px + this.velDir.x * this.speed * dt;
    let [rx, rz] = this.collide(nx, this.pz);
    nx = rx;
    [rx, rz] = this.collide(nx, this.pz + this.velDir.y * this.speed * dt);
    this.px = rx;
    this.pz = rz;
    const actual = Math.hypot(this.px - ox, this.pz - oz) / Math.max(dt, 1e-4);
    // puzzle: turn to face the wall console
    if (this.puzzle) {
      const ty = this.puzzle.group.position.x > 0 ? Math.PI / 2 : -Math.PI / 2;
      this.yaw += angDiff(ty, this.yaw) * (1 - Math.exp(-dt * 8));
    }
    const stepped = this.pm.animate(dt, actual, WALK, RUN);
    if (stepped) audio.step(actual > 2.7);
    this.pm.root.position.set(this.px, 0, this.pz);
    this.pm.root.rotation.y = this.yaw;
    // exit
    const ez = 4 * this.D.L + this.D.hl;
    if (!this.escaping && this.doors[4].state === 4 && this.pz > ez + 0.35) this.startEscape();
    // compartment tracking
    this.curComp = clamp(Math.floor((this.pz + this.D.hl) / this.D.L), 0, 4);
  }
  startEscape() {
    this.escaping = 0.001;
    this.F.escaped = true;
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
    ui.set({ hasSave: false, prompt: null });
    audio.escape();
  }

  updateInteract(dt: number) {
    this.interactCool = Math.max(0, this.interactCool - dt);
    let best: any = null,
      bs = 1e9;
    if (!this.puzzle && !ui.get().note && !this.escaping && this.blend < 0.02) {
      for (const it of this.inters) {
        const p = it.pos;
        const dx = p.x - this.px,
          dz = p.z - this.pz;
        const d = Math.hypot(dx, dz);
        if (d > it.range) continue;
        const ang = d < 0.35 ? 0 : Math.abs(angDiff(Math.atan2(dx, dz), this.camYawS));
        if (ang > it.fov) continue;
        const g = it.get();
        if (!g) continue;
        const score = d + ang * 0.9;
        if (score < bs) {
          bs = score;
          best = { it, g };
        }
      }
    }
    this.cur = best;
    const sig = best ? best.g.text + "|" + best.g.sub + "|" + best.g.actionable : "";
    if (sig !== this.curSig) {
      this.curSig = sig;
      ui.set({ prompt: best ? { text: best.g.text, sub: best.g.sub, actionable: !!best.g.actionable } : null });
    }
  }

  updateEvents(dt: number) {
    this.evTimer -= dt;
    const solved = [this.F.news.solved, this.F.calc.solved, this.F.panel.done, this.F.machine.solved].filter(Boolean).length;
    const tension = solved / 4 + this.curComp * 0.08;
    if (this.evTimer <= 0) {
      this.evTimer = (6 + Math.random() * 10) / (1 + tension * 0.9);
      const r = Math.random();
      const z = this.pz;
      const rp = () => [(Math.random() - 0.5) * 3.5, 1.5, z + (Math.random() - 0.5) * 8];
      if (r < 0.2) {
        this.swayBoost = 1;
        audio.creak(rp());
      } else if (r < 0.42) {
        const c = this.comps[clamp(this.curComp + (Math.random() < 0.3 ? 1 : 0), 0, 4)];
        c.flick = 0.5 + Math.random() * 1.2;
        audio.flickerBuzz([0, 2.4, c.z0]);
      } else if (r < 0.58) {
        this.rattleT = 1.3;
        audio.rattle(rp());
      } else if (r < 0.72) audio.distant();
      else if (r < 0.84) {
        const sb = this.sparkBoxes[this.curComp];
        this.emitSparks(sb.pos, 16);
        audio.zap([sb.pos.x, sb.pos.y, sb.pos.z]);
        this.comps[this.curComp].flick = 0.35;
      } else if (r < 0.92) {
        this.rumbleT = 1.6;
        audio.creak(rp());
        this.swayBoost = 0.8;
        audio.distant();
      } else {
        audio.insect([0, 2.3, this.comps[this.curComp].z0]);
        audio.strap(rp());
        this.swayBoost = 0.5;
      }
    }
    audio.updateMusic(dt, tension);
  }
  emitSparks(p: THREE.Vector3, n: number) {
    const s = this.spark;
    for (let i = 0; i < n; i++) {
      const k = s.n++ % 40;
      s.pos[k * 3] = p.x;
      s.pos[k * 3 + 1] = p.y;
      s.pos[k * 3 + 2] = p.z;
      s.vel[k * 3] = (Math.random() - 0.5) * 2;
      s.vel[k * 3 + 1] = Math.random() * 1.5;
      s.vel[k * 3 + 2] = (Math.random() - 0.5) * 2;
      s.life[k] = 0.4 + Math.random() * 0.4;
    }
  }

  updateAmbientFx(dt: number, t: number) {
    // straps
    this.swayBoost = Math.max(0, this.swayBoost - dt * 0.35);
    this.rattleT = Math.max(0, this.rattleT - dt);
    this.rumbleT = Math.max(0, this.rumbleT - dt);
    this.straps.forEach((s, i) => {
      s.rotation.x = Math.sin(t * 0.8 + i * 1.7) * (0.012 + this.swayBoost * 0.12);
      s.rotation.z = Math.sin(t * 0.6 + i) * (0.008 + this.swayBoost * 0.07);
    });
    for (const g of this.glass) g.position.x = g.userData.bx + (this.rattleT > 0 ? (Math.random() - 0.5) * 0.006 : 0);
    // dust drifts around player
    const dp = this.dust.geometry.attributes.position;
    const a = dp.array as Float32Array;
    for (let i = 0; i < a.length; i += 3) {
      a[i] += Math.sin(t * 0.3 + i) * 0.04 * dt;
      a[i + 1] += (Math.sin(t * 0.2 + i * 0.7) * 0.03 - 0.012) * dt;
      a[i + 2] += Math.cos(t * 0.25 + i) * 0.04 * dt;
      const wx = a[i] + this.px - this.dustO.x;
      if (a[i] < -3) a[i] += 6;
      if (a[i] > 3) a[i] -= 6;
      if (a[i + 2] < -3) a[i + 2] += 6;
      if (a[i + 2] > 3) a[i + 2] -= 6;
      if (a[i + 1] < 0) a[i + 1] += 2.6;
    }
    dp.needsUpdate = true;
    this.dust.position.set(this.px, 0, this.pz);
    // insects orbit the current ceiling light
    const ip = this.insects.geometry.attributes.position;
    const z0 = this.comps[this.curComp].z0;
    for (let i = 0; i < ip.count; i++) {
      const ph = t * (2 + (i % 3)) + i * 2.1;
      const r = 0.25 + 0.15 * Math.sin(t * 0.7 + i);
      ip.setXYZ(i, Math.cos(ph) * r + (i % 2 ? 0.0 : 0), 2.45 + Math.sin(ph * 1.7) * 0.12, z0 + Math.sin(ph) * r * 1.6);
    }
    ip.needsUpdate = true;
    // sparks
    const s = this.spark;
    const sp = this.sparks.geometry.attributes.position;
    for (let k = 0; k < 40; k++) {
      if (s.life[k] > 0) {
        s.life[k] -= dt;
        s.vel[k * 3 + 1] -= 6 * dt;
        s.pos[k * 3] += s.vel[k * 3] * dt;
        s.pos[k * 3 + 1] += s.vel[k * 3 + 1] * dt;
        s.pos[k * 3 + 2] += s.vel[k * 3 + 2] * dt;
        sp.setXYZ(k, s.pos[k * 3], s.pos[k * 3 + 1], s.pos[k * 3 + 2]);
      } else sp.setXYZ(k, 0, -50, 0);
    }
    sp.needsUpdate = true;
    this.outside.update(dt);
  }
  dustO = { x: 0 };

  updateLights(dt: number, t: number) {
    const P = this.F.panel.done;
    if (this.surgeT > 0) this.surgeT -= dt;
    this.comps.forEach((c, i) => {
      let power = 1;
      if (i === 3) power = P ? 1 : 0.2;
      if (i === 4) power = P ? 1 : 0.06;
      let m = c.base * power;
      if (c.flick > 0) {
        c.flick -= dt;
        m *= Math.random() < 0.55 ? 0.08 : 0.6 + Math.random() * 0.5;
      }
      // damaged tube in C3 stutters on its own
      if (i === 2 && Math.sin(t * 0.7) > 0.985 && Math.random() < 0.5) m *= 0.15;
      if (this.surgeT > 0 && i >= 3) m = Math.random() < 0.5 ? 2.2 : 0.05;
      c.mult += (m - c.mult) * Math.min(1, dt * 18);
      c.fx.light.intensity = 14 * c.mult;
      c.fx.tubeMat.emissiveIntensity = 1.3 * c.mult;
    });
    // flashlight
    const f = this.lights.flash;
    this.flashI += ((this.flashOn ? 70 : 0) - this.flashI) * Math.min(1, dt * 16);
    f.intensity = this.flashI;
    const sh = new THREE.Vector3(this.px - Math.cos(this.yaw) * 0.0 + Math.sin(this.yaw) * 0.15, 1.3, this.pz + Math.cos(this.yaw) * 0.15);
    f.position.copy(sh);
    const dir = new THREE.Vector3().subVectors(this.camLook, this.camera.position).normalize();
    f.target.position.copy(this.camera.position).addScaledVector(dir, 9);
    f.target.updateMatrixWorld();
    this.lights.fill.position.set(this.px - Math.sin(this.camYawS) * 0.9, 2.0, this.pz - Math.cos(this.camYawS) * 0.9);
  }

  cameraBounds() {
    const D = this.D;
    let zmin = -D.hl + 0.12,
      zmax = 4 * D.L + D.hl + 3.2;
    for (const d of this.doors) {
      const closed = d.state < 3 || (d.state === 3 && d.t < 0.9);
      if (!closed) continue;
      if (d.z <= this.pz) zmin = Math.max(zmin, d.z + 0.2);
      else zmax = Math.min(zmax, d.z - 0.2);
    }
    return { x0: -D.hw + 0.25, x1: D.hw - 0.25, y0: 0.9, y1: D.CH - 0.15, z0: zmin, z1: zmax };
  }

  updateCamera(dt: number, t: number) {
    const screen = ui.get().screen;
    // smooth angles
    const k = 1 - Math.exp(-dt * 14);
    this.camYawS += angDiff(this.camYaw, this.camYawS) * k;
    this.camPitchS += (this.camPitch - this.camPitchS) * k;
    let pivot: THREE.Vector3, tpPos: THREE.Vector3, tpLook: THREE.Vector3;
    if (screen === "menu" || !this.pm) {
      // attract mode
      const a = t * 0.12;
      tpPos = new THREE.Vector3(Math.sin(a) * 0.55, 1.75, -1.7);
      tpLook = new THREE.Vector3(Math.sin(a * 0.7) * 0.3, 1.25, 1.6);
      this.camPos.lerp(tpPos, 0.2);
      this.camLook.lerp(tpLook, 0.2);
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(this.camLook);
      return;
    }
    pivot = new THREE.Vector3(this.px, 1.45, this.pz);
    const cy = Math.cos(this.camPitchS),
      sy = Math.sin(this.camPitchS);
    const dist = this.escaping ? 2.0 : 2.45;
    const dir = new THREE.Vector3(-Math.sin(this.camYawS) * cy, sy, -Math.cos(this.camYawS) * cy);
    const B = this.cameraBounds();
    let tmax = dist;
    const lim = (o: number, d: number, lo: number, hi: number) => {
      if (d > 1e-5) tmax = Math.min(tmax, (hi - o) / d);
      else if (d < -1e-5) tmax = Math.min(tmax, (lo - o) / d);
    };
    lim(pivot.x, dir.x, B.x0, B.x1);
    lim(pivot.y, dir.y, B.y0, B.y1);
    lim(pivot.z, dir.z, B.z0, B.z1);
    tmax = clamp(tmax, 0.55, dist);
    tpPos = pivot.clone().addScaledVector(dir, tmax);
    tpLook = new THREE.Vector3(this.px + Math.sin(this.camYawS) * 1.0, 1.28 - sy * 0.2, this.pz + Math.cos(this.camYawS) * 1.0);
    // spring (snap when pulled in by collision)
    const cur = this.camPos.distanceTo(pivot);
    if (tmax < cur - 0.001 || this.camPos.lengthSq() < 1) this.camPos.copy(tpPos);
    else this.camPos.lerp(tpPos, 1 - Math.exp(-dt * 10));
    this.camPos.x = clamp(this.camPos.x, B.x0, B.x1);
    this.camPos.y = clamp(this.camPos.y, B.y0, B.y1);
    this.camPos.z = clamp(this.camPos.z, B.z0, B.z1);
    this.camLook.lerp(tpLook, 1 - Math.exp(-dt * 16));
    // puzzle close-up blend
    const tb = this.puzzle ? 1 : 0;
    this.blend += clamp(tb - this.blend, -dt * 1.5, dt * 1.5);
    let pos = this.camPos.clone(),
      look = this.camLook.clone();
    if (this.blend > 0.001) {
      const pz = this.puzzle ? this.puzzle.camWorld() : this.lastPuz;
      if (this.puzzle) this.lastPuz = pz;
      const e = ease(this.blend);
      if (pz) {
        pos.lerp(pz.pos, e);
        look.lerp(pz.look, e);
      }
      this.camera.fov += ((50 - this.camera.fov) * 0.1) * e;
    } else {
      const base = window.innerWidth / window.innerHeight < 1.4 ? 66 : 58;
      this.camera.fov += (base - this.camera.fov) * 0.1;
    }
    this.camera.updateProjectionMatrix();
    // train vibration
    const v = 0.0016 + this.rumbleT * 0.006;
    pos.y += Math.sin(t * 41) * v + Math.sin(t * 17.3) * v * 0.6;
    pos.x += Math.sin(t * 29) * v * 0.5;
    this.camera.position.copy(pos);
    this.camera.lookAt(look);
    this.pm.root.visible = this.blend < 0.35 || !this.puzzle && this.blend < 0.5;
    // fade out the character if camera is very close
    const dd = pos.distanceTo(pivot);
    this.pm.root.visible = this.pm.root.visible && dd > 0.7;
  }
  lastPuz: any = null;

  updateVisibility() {
    const c = this.curComp;
    for (let i = 0; i < 5; i++) {
      let vis = i === c;
      if (i === c + 1 && this.doors[c].state >= 3) vis = true;
      if (i === c - 1 && c > 0 && this.doors[c - 1].state >= 3) vis = true;
      if (!this.pm || ui.get().screen === "menu") vis = i <= 1;
      this.comps[i].grp.visible = vis;
    }
    this.dust.visible = !this.puzzle && this.blend < 0.2;
    this.outside.glow.visible = this.doors[4].state >= 1;
  }

  update(dt: number) {
    if (!this.ready) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    this.time += dt;
    const t = this.time;
    const screen = ui.get().screen;
    const live = screen === "playing";
    if (screen === "paused" || screen === "settings" || screen === "credits") {
      if (screen === "settings" && ui.get().settingsFrom === "menu") {
        this.updateAmbientFx(dt, t);
        this.updateCamera(dt, t);
      }
      this.renderer.render(this.scene, this.camera);
      return;
    }
    // timers
    for (let i = this.timers.length - 1; i >= 0; i--) {
      this.timers[i].t -= dt;
      if (this.timers[i].t <= 0) {
        const f = this.timers[i].fn;
        this.timers.splice(i, 1);
        f();
      }
    }
    if (live || screen === "ending") {
      this.updatePlayer(dt);
      this.updateInteract(dt);
      if (live) this.updateEvents(dt);
      // falling items
      for (let i = this.falling.length - 1; i >= 0; i--) {
        const f = this.falling[i];
        const p = this.props[f.id];
        f.vy -= 9.8 * dt;
        p.position.y += f.vy * dt;
        if (p.position.y <= 0.012) {
          p.position.y = 0.012;
          this.F.items[f.id].pos = p.position.toArray();
          this.falling.splice(i, 1);
          audio.drop();
          this.save();
        }
      }
      // sparkle pulse on collectibles
      for (const id in this.props) {
        const sp = this.props[id].getObjectByName("sparkle");
        if (sp) sp.material.opacity = 0.3 + 0.3 * Math.sin(t * 3 + id.length);
      }
      this.saveT += dt;
      if (this.saveT > 6) {
        this.saveT = 0;
        this.save();
      }
    }
    // escape sequence
    if (this.escaping) {
      this.escaping += dt;
      ui.set({ fade: clamp((this.escaping - 1.8) / 2.4, 0, 1) });
      if (this.escaping > 4.6 && ui.get().screen !== "ending") ui.set({ screen: "ending" });
    }
    this.updateDoors(dt);
    this.updateAmbientFx(dt, t);
    this.updateLights(dt, t);
    if (this.puzzle) {
      this.puzzle.update(dt, t);
      this.hintT -= dt;
      if (this.hintT <= 0) {
        this.hintT = 0.25;
        const h = this.puzzle.hint();
        if (h !== this.hintSig) {
          this.hintSig = h;
          ui.set({ puzzle: { title: this.puzzle.title, hint: h } });
        }
      }
    } else {
      // keep non-active puzzles animating (e.g. closing animations)
      for (const k in this.puzzles) this.puzzles[k].update(dt, t);
    }
    this.updateCamera(dt, t);
    audio.setListener(this.camera.position.x, this.camera.position.y, this.camera.position.z, this.camLook.x - this.camera.position.x, this.camLook.z - this.camera.position.z);
    this.updateVisibility();
    this.renderer.render(this.scene, this.camera);
  }
}

export const game = new Game();
if (typeof window !== "undefined") (window as any).__game = game;
