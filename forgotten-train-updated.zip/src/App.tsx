import { useEffect, useRef, useState } from "react";
import { game, ITEM_DEFS } from "./game/Game";
import { ui, useUI, Quality } from "./game/store";
import { itemIcon } from "./game/textures";
import { audio } from "./game/audio";

// ------------------------------------------------------------------ music player
class MenuMusic {
  private el: HTMLAudioElement | null = null;
  private playing = false;

  play() {
    if (this.playing) return;
    if (!this.el) {
      this.el = new Audio("music.opus");
      this.el.loop = true;
      this.el.volume = 0.55;
    }
    this.el.play().catch(() => {});
    this.playing = true;
  }

  stop() {
    if (!this.el || !this.playing) return;
    this.el.pause();
    this.el.currentTime = 0;
    this.playing = false;
  }
}
const menuMusic = new MenuMusic();

// ------------------------------------------------------------------ in-game controls
function Joystick() {
  const [st, setSt] = useState<{ ox: number; oy: number; x: number; y: number } | null>(null);
  const id = useRef<number | null>(null);
  const R = 58;
  const move = (e: React.PointerEvent) => {
    if (id.current !== e.pointerId || !st) return;
    let dx = e.clientX - st.ox, dy = e.clientY - st.oy;
    const l = Math.hypot(dx, dy);
    if (l > R) { dx = (dx / l) * R; dy = (dy / l) * R; }
    setSt({ ...st, x: dx, y: dy });
    game.joystick(dx / R, -dy / R);
  };
  const end = (e: React.PointerEvent) => {
    if (id.current !== e.pointerId) return;
    id.current = null; setSt(null); game.joystick(0, 0);
  };
  return (
    <div className="joy-zone"
      onPointerDown={(e) => {
        if (id.current !== null) return;
        id.current = e.pointerId;
        (e.currentTarget as any).setPointerCapture(e.pointerId);
        setSt({ ox: e.clientX, oy: e.clientY, x: 0, y: 0 });
        audio.init();
      }}
      onPointerMove={move} onPointerUp={end} onPointerCancel={end}>
      {st && (<>
        <div className="joy-base" style={{ left: st.ox - R, top: st.oy - R, width: R * 2, height: R * 2 }} />
        <div className="joy-knob" style={{ left: st.ox + st.x - 24, top: st.oy + st.y - 24 }} />
      </>)}
    </div>
  );
}

function LookZone() {
  const id = useRef<number | null>(null);
  const last = useRef({ x: 0, y: 0 });
  return (
    <div className="look-zone"
      onPointerDown={(e) => { if (id.current !== null) return; id.current = e.pointerId; (e.currentTarget as any).setPointerCapture(e.pointerId); last.current = { x: e.clientX, y: e.clientY }; }}
      onPointerMove={(e) => { if (id.current !== e.pointerId) return; game.look(e.clientX - last.current.x, e.clientY - last.current.y); last.current = { x: e.clientX, y: e.clientY }; }}
      onPointerUp={(e) => { if (id.current === e.pointerId) id.current = null; }}
      onPointerCancel={(e) => { if (id.current === e.pointerId) id.current = null; }} />
  );
}

function FlashIcon() {
  const on = useUI((s) => s.flashlight);
  return (
    <button className={"hud-btn flash-btn" + (on ? " on" : "")} aria-label="Flashlight" onPointerDown={(e) => (e.stopPropagation(), game.toggleFlashlight())}>
      <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M7 3h10l-1.5 5h-7z" /><path d="M8.5 8h7v11a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2z" /><path d="M12 11v3" />
      </svg>
    </button>
  );
}

function Hotbar() {
  const hotbar = useUI((s) => s.hotbar);
  const sel = useUI((s) => s.selected);
  const puzzle = useUI((s) => s.puzzle);
  const cur = hotbar[sel];
  return (
    <div className="hotbar-wrap">
      {cur && !puzzle && (<button className="drop-chip" onPointerDown={(e) => (e.stopPropagation(), game.dropSelected())}>Drop · {ITEM_DEFS[cur].name}</button>)}
      {cur && ITEM_DEFS[cur].readable && sel >= 0 && <div className="slot-hint">tap selected slot to read</div>}
      <div className="hotbar">
        {hotbar.map((id, i) => (
          <button key={i} className={"slot" + (i === sel ? " sel" : "")} onPointerDown={(e) => (e.stopPropagation(), game.selectSlot(i))} aria-label={"Slot " + (i + 1)}>
            <span className="slot-n">{i + 1}</span>
            {id && <img src={itemIcon(id)} alt={ITEM_DEFS[id].name} draggable={false} />}
          </button>
        ))}
      </div>
    </div>
  );
}

function Prompt() {
  const p = useUI((s) => s.prompt);
  if (!p) return null;
  return (
    <button className={"prompt" + (p.actionable ? "" : " dim")} onPointerDown={(e) => (e.stopPropagation(), p.actionable && game.interact())}>
      <span className="prompt-main">{p.text}</span>
      {p.sub && <span className="prompt-sub">{p.sub}</span>}
    </button>
  );
}

function Toast() {
  const t = useUI((s) => s.toast);
  const pz = useUI((s) => s.puzzle);
  if (!t) return null;
  return <div key={t.id} className={"toast " + t.kind + (pz ? " low" : "")}>{t.text}</div>;
}

function PuzzleOverlay() {
  const p = useUI((s) => s.puzzle);
  const down = useRef({ x: 0, y: 0 });
  if (!p) return null;
  return (<>
    <div className="puzzle-layer"
      onPointerDown={(e) => (down.current = { x: e.clientX, y: e.clientY })}
      onPointerUp={(e) => { if (Math.hypot(e.clientX - down.current.x, e.clientY - down.current.y) < 14) game.puzzleTap(e.clientX, e.clientY); }} />
    <button className="back-btn" onPointerDown={(e) => (e.stopPropagation(), game.exitPuzzle())}>‹ Back</button>
    <div className="puzzle-title">{p.title}</div>
    <div className="puzzle-hint">{p.hint}</div>
  </>);
}

function NoteModal() {
  const n = useUI((s) => s.note);
  if (!n) return null;
  return (
    <div className="modal-bg" onPointerDown={() => game.closeNote()}>
      <div className="note-card" onPointerDown={(e) => e.stopPropagation()}>
        <h3>{n.title}</h3>
        {n.img && <img src={n.img} alt="" className="note-img" />}
        <p>{n.body}</p>
        <button className="btn small" onClick={() => game.closeNote()}>Close</button>
      </div>
    </div>
  );
}

function Hud() {
  const puzzle = useUI((s) => s.puzzle);
  const fade = useUI((s) => s.fade);
  return (<>
    {!puzzle && (<><LookZone /><Joystick /><FlashIcon /><Prompt /></>)}
    <button className="hud-btn pause-btn" aria-label="Pause" onPointerDown={(e) => (e.stopPropagation(), game.pause())}>
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
        <rect x="6" y="5" width="4" height="14" rx="1" /><rect x="14" y="5" width="4" height="14" rx="1" />
      </svg>
    </button>
    <Hotbar /><Toast /><PuzzleOverlay /><NoteModal />
    {fade > 0 && <div className="white-fade" style={{ opacity: fade }} />}
  </>);
}

// ------------------------------------------------------------------ IG icon
function IGIcon() {
  return (
    <button
      className="ig-btn"
      aria-label="Instagram"
      onPointerDown={(e) => { e.stopPropagation(); window.open("https://www.instagram.com/zx_4xe", "_blank"); }}>
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
      </svg>
    </button>
  );
}

// ------------------------------------------------------------------ menus
function Settings({ onBack }: { onBack: () => void }) {
  const s = useUI((x) => x.settings);
  const set = (p: any) => { ui.set({ settings: { ...ui.get().settings, ...p } }); ui.saveSettings(); game.applySettings(); };
  const Slider = ({ label, k, min = 0, max = 1, step = 0.01 }: any) => (
    <label className="row">
      <span>{label}</span>
      <input type="range" min={min} max={max} step={step} value={(s as any)[k]} onChange={(e) => set({ [k]: +e.target.value })} />
      <em>{Math.round(((s as any)[k] / max) * 100)}%</em>
    </label>
  );
  return (
    <div className="panel wide">
      <h2>Settings</h2>
      <Slider label="Master volume" k="master" />
      <Slider label="Sound effects" k="sfx" />
      <Slider label="Music" k="music" />
      <Slider label="Camera sensitivity" k="sens" min={0.3} max={2.5} step={0.05} />
      <div className="row">
        <span>Graphics quality</span>
        <div className="seg">
          {(["low", "medium", "high"] as Quality[]).map((q) => (
            <button key={q} className={s.quality === q ? "on" : ""} onClick={() => set({ quality: q })}>{q}</button>
          ))}
        </div>
        <em />
      </div>
      <button className="btn" onClick={onBack}>Back</button>
    </div>
  );
}

function Menus() {
  const screen = useUI((s) => s.screen);
  const from = useUI((s) => s.settingsFrom);
  const hasSave = useUI((s) => s.hasSave);
  const pct = useUI((s) => s.loadPct);
  const err = useUI((s) => s.loadErr);

  // Play menu music on menu screen, stop when game starts
  useEffect(() => {
    if (screen === "menu") {
      menuMusic.play();
    } else {
      menuMusic.stop();
    }
  }, [screen]);

  if (screen === "loading")
    return (
      <div className="menu-bg center">
        <h1 className="title small">THE FORGOTTEN TRAIN</h1>
        <div className="bar"><div style={{ width: pct + "%" }} /></div>
        <p className="muted">{err ? "Failed to load models: " + err : `Loading train and character models… ${pct}%`}</p>
        {err && <button className="btn" onClick={() => location.reload()}>Retry</button>}
      </div>
    );

  if (screen === "menu")
    return (
      <div className="menu-bg left">
        <IGIcon />
        <div className="menu-col">
          <h1 className="title">THE FORGOTTEN<br />TRAIN</h1>
          <p className="muted">Five carriages. Five locks. One way out.</p>
          <button className="btn" onClick={() => game.startNew()}>Start Game</button>
          {hasSave && <button className="btn" onClick={() => game.continueGame()}>Continue</button>}
          <button className="btn" onClick={() => (audio.init(), ui.set({ screen: "settings", settingsFrom: "menu" }))}>Settings</button>
          <button className="btn" onClick={() => ui.set({ screen: "credits" })}>Credits</button>
        </div>
      </div>
    );

  if (screen === "settings")
    return (
      <div className="menu-bg center dim">
        <Settings onBack={() => ui.set({ screen: from === "pause" ? "paused" : "menu" })} />
      </div>
    );

  if (screen === "credits")
    return (
      <div className="menu-bg center dim">
        <div className="panel wide">
          <h2>Credits</h2>
          <div className="credits-body">

            <p className="credits-title">THE FORGOTTEN TRAIN</p>
            <p className="credits-sub">An Adventure into the Unknown</p>

            <div className="credits-divider" />

            <p className="credits-section">GAME INTRODUCTION</p>
            <p className="credits-text">
              THE FORGOTTEN TRAIN is a mysterious 3D adventure and horror puzzle game that takes players into an abandoned Indian passenger train. The journey begins inside an old, forgotten train surrounded by darkness and mystery. As players explore its interconnected compartments, they discover hidden clues, unusual objects and challenging puzzles. Every compartment holds a part of the mystery, and solving each challenge brings the player closer to discovering the truth and finding a way out.
            </p>

            <div className="credits-divider" />

            <p className="credits-section">GAME THEME & VISUAL STYLE</p>
            <p className="credits-text">
              The game combines mystery, atmospheric horror, exploration and puzzle-solving in a cinematic 3D anime-inspired visual style. Its environment features aged train interiors, worn passenger seats, dusty windows, flickering lights and mysterious darkness. Carefully designed lighting, environmental effects, immersive camera movement and interactive 3D puzzles create a suspenseful experience focused on exploration, discovery and tension.
            </p>

            <div className="credits-divider" />

            <p className="credits-section">OWNER & DEVELOPER</p>
            <p className="credits-text">
              Project: THE FORGOTTEN TRAIN{"\n"}
              Brand / Owner: ZX 4XE{"\n"}
              Contact: Instagram @zx_4xe
            </p>

            <div className="credits-divider" />

            <p className="credits-section">PRIVACY</p>
            <p className="credits-text">
              THE FORGOTTEN TRAIN is designed to provide a gameplay experience without requiring players to share unnecessary personal information. The game does not request sensitive personal information such as passwords, home addresses or private account details. If the game uses analytics, advertisements or third-party technologies, those services may process technical information under their own privacy policies. The developer does not intend to sell players' personal information. This policy will be updated if the game's data collection or external services change.
            </p>

            <div className="credits-divider" />

            <p className="credits-section">COPYRIGHT</p>
            <p className="credits-text">
              Copyright © 2026 ZX 4XE. All Rights Reserved.{"\n\n"}
              THE FORGOTTEN TRAIN and its original creative content — including game concept and story, game design and puzzle designs, characters and original artwork, graphics, environments and visual designs, animations and original audio, source code and game systems, and branding, logos and project materials — are the property of ZX 4XE.{"\n\n"}
              Unauthorized copying, reproduction, modification, redistribution, re-uploading, commercial exploitation, asset extraction or claiming ownership of the original project content without prior written permission from the owner is strictly prohibited.{"\n\n"}
              Third-party assets, software, libraries, music and other licensed materials remain the property of their respective owners and are subject to their applicable licenses.
            </p>

            <div className="credits-divider" />

            <p className="credits-copy">© 2026 ZX 4XE — ALL RIGHTS RESERVED</p>
          </div>
          <button className="btn" onClick={() => ui.set({ screen: "menu" })}>Back</button>
        </div>
      </div>
    );

  if (screen === "paused")
    return (
      <div className="menu-bg center dim">
        <div className="panel">
          <h2>Paused</h2>
          <button className="btn" onClick={() => game.resume()}>Resume</button>
          <button className="btn" onClick={() => game.restart()}>Restart</button>
          <button className="btn" onClick={() => ui.set({ screen: "settings", settingsFrom: "pause" })}>Settings</button>
          <button className="btn" onClick={() => game.toMenu()}>Return to Main Menu</button>
        </div>
      </div>
    );

  if (screen === "ending")
    return (
      <div className="menu-bg center ending">
        <h1 className="title dark">YOU ESCAPED</h1>
        <p className="dark-p">The doors close behind you. The fog swallows the train.</p>
        <p className="dark-p">But somewhere, a light is still flickering…</p>
        <button className="btn light" onClick={() => game.toMenu()}>Main Menu</button>
      </div>
    );

  return null;
}

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const screen = useUI((s) => s.screen);
  useEffect(() => { if (ref.current) game.mount(ref.current); }, []);
  return (
    <div className="root" onContextMenu={(e) => e.preventDefault()}>
      <canvas ref={ref} className="gl" />
      {(screen === "playing" || screen === "ending") && <Hud />}
      <Menus />
      <div className="rotate-msg">
        <div>
          <div style={{ fontSize: 44 }}>⟳</div>
          Please rotate your device<br />to landscape
        </div>
      </div>
    </div>
  );
}
