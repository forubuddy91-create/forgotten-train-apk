# THE FORGOTTEN TRAIN — 3D horror escape (HTML5 / three.js)

Landscape-only mobile 3D horror/puzzle game. React + Vite + three.js, built to a single `dist/index.html`.

## Run locally
```bash
npm install
npm run dev        # development server
npm run build      # outputs dist/index.html (single file, JS/CSS inlined)
npm run preview    # serve the production build
```
Open on an Android phone (same network) in Chrome, landscape. Desktop: WASD / arrows move, Shift run, drag with mouse to look, `E` interact, `F` flashlight, `1-5` hotbar, `Q` drop, `Esc` pause.

## Host online
Upload `dist/index.html` (plus the optional `dist/models/` folder) to any static host (GitHub Pages, Netlify, itch.io HTML5, ...).
The GLB files are loaded from the original GitHub-Pages URLs first and fall back to `./models/*.glb`.

## Project structure
```
index.html                 entry + mobile meta
public/models/             local copies of the two supplied GLBs (fallback)
src/App.tsx                menus, HUD (joystick, look zone, hotbar, prompts, puzzle overlay)
src/index.css              UI theme
src/game/Game.ts           engine: loading, 5 instances, player, camera, collision, doors, interaction, save
src/game/world.ts          shell/doors/lights/outside dressing built AROUND the train GLB
src/game/puzzles.ts        the four 3D close-up puzzles
src/game/character.ts      supplied character GLB + procedural limb animation (vertex shader)
src/game/audio.ts          procedural layered audio (Web Audio)
src/game/textures.ts       procedural textures, newspaper, icons
src/game/store.ts          UI state + settings
```

## Asset inspection results (measured at load, see console `[train GLB] measured`)
* The **train GLB** is one mesh normalised to a 1 × 0.264 × 1 box. It contains **only the two facing leather benches** (inner edge at |x| = 0.255 u). It has no walls, floor, ceiling, windows or door geometry — the reference screenshot shows a full carriage that is not in the file.
  The GLB is therefore used untouched as the seat module (scaled 4.4 m/unit → 4.41 m × 4.41 m bay, bench inner edge ≈ 1.12 m), loaded **once** and shared by five meshes at z offsets of exactly the measured length. Walls, floor, ceiling, windows, bulkheads/doors, lights, straps etc. are separate meshes in `world.ts` styled after the reference image.
* The **character GLB** is a single static, un-rigged mesh (feet at y = -0.5, height 1.0 u, faces +Z). Skeletal clips do not exist, so walking/running/interact/pickup are driven by a vertex-shader limb pose applied to the original mesh (geometry/material file untouched).
* The train URL given in the brief returns 404; the file lives in the `Assets-` repository, which is the first URL tried.

## Walkthrough
1. C1: read the note, search the torn seat → Brass Key → unlock door (select key in hotbar). Grab the newspaper fragment.
2. C2: find the other fragments (bench + under-bench gap), pin them to the evidence board, fix order/orientation → hidden ink reveals the rule and 3 route signs.
3. C3: Conductor's Test → `054` + red button → drawer with screwdriver, door unlocks.
4. C4: unscrew panel (screwdriver selected), breaker OFF, wires red → blue → yellow, breaker ON → power; route board shows signs 4–5.
5. C5: set the five rings (Moon, Triangle, Star, Diamond, Circle) → exit unbolts → escape.
